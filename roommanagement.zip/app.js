var express = require('express');
var cors = require('cors');
var app = express();
//var logFile = fs.createWriteStream('./myLogFile.log', {flags: 'a'});
//app.use(express.logger({stream: logFile}));
//var db = require('./db');
// var bodyParser = require('body-parser');

// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());
app.use(cors());
 
// var bodyParser = require('body-parser');
// app.use(bodyParser.json({limit: '50mb'}));
// app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));

app.use(express.json({limit: '50mb'}));
app.use(express.urlencoded({limit: '50mb'}));


//Routes declarataion
// const categoryRoutes = require("./api/router/CategoryRouter");
// const subcategoryRoutes = require("./api/router/SubCategoryRoutes");
// const countryRoutes = require("./api/router/CountryRouter");
// const userRoutes =  require("./api/router/UserRouter");
 //const authRoutes =  require("./api/router/AuthRouter");
// const imageRoutes =  require("./api/router/ImageRouter");
// const contestRoutes =  require("./api/router/ContestRouter");
// const searchcontestRoutes =  require("./api/router/SearchContestRouter");
// const transationRoutes =  require("./api/router/TransationRouter");
const userRoutes =  require("./api/router/UserRouter");

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
	res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,x-access-token,authorization");
    next();
});	


//>>>  JP:[20-Sep-2018] Set Category Routes
// app.use("/category", categoryRoutes);
// app.use("/subcategory", subcategoryRoutes);
// app.use("/country", countryRoutes);
app.use("/user", userRoutes);
//app.use("/auth", authRoutes);
// app.use("/imageupload", imageRoutes);
// app.use("/contest", contestRoutes);
// app.use("/search", searchcontestRoutes);
// app.use("/transation", transationRoutes);
//app.use("/transation", transationRoutes);

app.get('/api', function (req, res) {
    res.status(200).send('API works.');
});

module.exports = app;
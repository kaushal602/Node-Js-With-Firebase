var express = require('express');
var modelCategory = require('../../model/Category');
var utility = require('../../Utility/Utility');
var VerifyToken = require('../../auth/VerifyToken');
const uuid = require('uuid');
var bcrypt = require('bcryptjs');
require('dotenv').config();

var request = require('superagent');
/****************** Email Code*********** */
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var handlebars = require('handlebars');
var fs = require('fs');
var readHTMLFile = function(path, callback) {
    fs.readFile(path, {encoding: 'utf-8'}, function (err, html) {
        if (err) {
            throw err;
            callback(err);
        }
        else {
            callback(null, html);
        }
    });
};
smtpTransport = nodemailer.createTransport(smtpTransport({
    service: 'gmail',
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_USER_PASS
    }
}));
 /******************* Email code End****************/

var AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.region,
  accessKeyId: process.env.aws_access_key_id,
  secretAccessKey: process.env.aws_secret_access_key,
  //endpoint: "http://192.168.1.26:8000/shell/"
});
var dynamodb = new AWS.DynamoDB();


exports.contest_create = (req, res) => {
    try {
        const id = uuid.v1();
        md = req.body;
        //console.log(md);
        if (!md.ContestName) {
            return utility.errorResponse(res, 'No ContestName provided.',null);
        }
        if (!md.Category) {
            return utility.errorResponse(res, 'No Category provided.',null);
        }
        if (!md.SubCategory) {
            return utility.errorResponse(res, 'No SubCategory provided.',null);
        }
        var Discription = md.Discription;
        if (!md.Discription) {
            Discription = "N/A";
        }
        var RulesAndRegulation = md.RulesAndRegulation;
        if (!md.RulesAndRegulation) {
            RulesAndRegulation = "N/A";
        }
        var Judges = md.Judges;
        if (!md.Judges) {
            Judges = "N/A";
        }
        var Prizes = md.Prizes;
        if (!md.Prizes) {
            Prizes = "N/A";
        }
        var AwardCeremony = md.AwardCeremony;
        if (!md.AwardCeremony) {
            AwardCeremony = "N/A";
        }
        var Address = md.Address;
        if (!md.Address) {
            Address = "Hong Kong";
        }
        if (!md.DeadlineDate) {
            return utility.errorResponse(res, 'No DeadlineDate provided.',null);
        }
        
        if (!md.DeadlineTime) {
            return utility.errorResponse(res, 'No DeadlineTime provided.',null);
        }
        if (!md.AcceptAfterDeadline) {
            return utility.errorResponse(res, 'No AcceptAfterDeadline provided.',null);
        }
        if (!md.ContestStartDate) {
            return utility.errorResponse(res, 'No ContestStartDate provided.',null);
        }
        if (!md.ContestStartTime) {
            return utility.errorResponse(res, 'No ContestStartTime provided.',null);
        }
        if (!md.ContestEndDate) {
            return utility.errorResponse(res, 'No ContestEndDate provided.',null);
        }
        if (!md.ContestEndTime) {
            return utility.errorResponse(res, 'No ContestEndTime provided.',null);
        }
        if (!md.ResultDate) {
            return utility.errorResponse(res, 'No ResultDate provided.',null);
        }
        if (!md.ResultTime) {
            return utility.errorResponse(res, 'No ResultTime provided.',null);
        }
        if (!md.PublishDate) {
            return utility.errorResponse(res, 'No PublishDate provided.',null);
        }
        if (!md.PublishTime) {
            return utility.errorResponse(res, 'No PublishTime provided.',null);
        }
        if (!md.Country) {
            return utility.errorResponse(res, 'No Country provided.',null);
        }
        if (!md.MultipleVideo) {
            return utility.errorResponse(res, 'No Video provided.',null);
        }
       
        
        
        var ContestFromDate = dateformate(md.ContestStartDate);
        //var ContestFromTime = dateformatewithtime(md.ContestStartTime);
        var ContestFromDateTime = new Date(ContestFromDate+ ' ' + md.ContestStartTime ).getTime().toString();
        console.log(ContestFromDateTime);
        var ContestToDate = dateformate(md.ContestEndDate);
        //var ContestToTime = dateformatewithtime(md.ContestEndTime);
        var ContestToDateTime = new Date(ContestToDate+ ' ' + md.ContestEndTime ).getTime().toString();
        console.log(ContestToDateTime);
        var CompareEnddatetime = new Date(ContestToDate+ ' ' + md.ContestEndTime ).getTime();
        
        var PublishDate = dateformate(md.PublishDate);
        //var PublishTime = dateformatewithtime(md.PublishTime);
        var PublishDateTime = new Date(PublishDate+ ' ' + md.PublishTime ).getTime().toString();
        console.log(PublishDateTime);
        if(md.PublishDate!='' && md.ContestStartDate!=''){
            if(new Date(md.PublishDate) > new Date(md.ContestStartDate)){
                return utility.errorResponse(res, 'Please Enter Valid Publish Date.',null);
            }
        }

        var ResultDate = dateformate(md.ResultDate);
        //var ResultTime = dateformatewithtime(md.ResultTime);
        var ResultDateTime = new Date(ResultDate+ ' ' + md.ResultTime ).getTime().toString();
        console.log(ResultDateTime);
        if(md.ResultDate!='' && md.ContestEndDate!=''){
            if(new Date(md.ResultDate) < new Date(md.ContestEndDate)){
                return utility.errorResponse(res, 'Please Enter Valid Result Date.',null);
            }
        }

        var DeadlineDate = dateformate(md.DeadlineDate);
        //var DeadlineTime = dateformatewithtime(md.DeadlineTime);
        var DeadlineDateTime = new Date(DeadlineDate+ ' ' + md.DeadlineTime ).getTime().toString();
        console.log(DeadlineDateTime);
        var compareDeadlinedatetime  = new Date(DeadlineDate+ ' ' + md.DeadlineTime ).getTime();
        //console.log(CompareEnddatetime);
        //console.log(compareDeadlinedatetime);
        if(md.DeadlineDate!='' && md.ContestStartDate!=''){
            if(compareDeadlinedatetime > CompareEnddatetime){
                return utility.errorResponse(res, 'Please Enter Valid Deadline Date.',null);
            }
        }
        // if(md.PrefferedLang== 'tc'){
        //     var TableName = process.env.CONTEST_TABLE_TC;
        //     var ContestMasterId = '0';
        // } else if(md.PrefferedLang== 'en') {
        var TableName = process.env.CONTEST_TABLE;
        //     var ContestMasterId = md.EnglishContestId;
        // } else {
        //     var TableName = process.env.CONTEST_TABLE;
        //     var ContestMasterId = md.EnglishContestId;
        // }
        // //console.log(ContestMasterId);
        
        //console.log(TableName);
        var group_data = [];
        var grpdata12 = md.Groups;
        grpdata12.forEach(function(grpdata) {
            var temp_data = {
                "M": {
                    "SubmissionType": {
                        "S": grpdata["SubmissionType"]
                    },
                    "NoOfParticipant": {
                        "N": grpdata["NoOfParticipant"]
                    },
                    "Gender": {
                        "S": grpdata["Gender"]
                    },
                    "GroupByAge": {
                        "B": grpdata["GroupByAge"]
                    },
                    "GroupAge": {
                        "S": grpdata["GroupAge"]
                    },
                    "Grade": {
                        "S": grpdata["Grade"]
                    },
                    "Fees": {
                        "S": grpdata["Fees"]
                    },
                    "TotalParticipant": {
                        "S": '0'
                    }
                }
            }
            group_data.push(temp_data);
        }); 
        var currentdate = new Date().getTime().toString();
        var ContestImagePath = 'N/A';
        //console.log(md.ContestImage);
        if(md.ContestImage!=''){
            singleImg = new Buffer(md.ContestImage.replace(/^data:image\/\w+;base64,/, ""),'base64');
            var bucketFolder = process.env.S3_BUCKET_NAME;
            var subdir = id;
            var singleimgFolder = bucketFolder + '/' + subdir;
            var bucket = new AWS.S3({
                params: {
                    Bucket: singleimgFolder
                }
            });
            var imgname = currentdate+md.ContestImageName;
            var contentToPost = {
                Key: imgname, 
                Body: singleImg,
                ACL: 'public-read',
                ContentEncoding: 'base64'
            };
            //ContestImagePath = singleimgFolder+'/'+imgname;
            ContestImagePath = imgname;
            bucket.putObject(contentToPost, function (error, data) {
                if (error) {
                    //console.log("Error in posting Content [" + error + "]");
                    return false;
                } 
                else {
                    //console.log(data);
                } 
            })
            .on('httpUploadProgress',function (progress) {
                //console.log(Math.round(progress.loaded / progress.total * 100) + '% done');
            });
        }
        //var MultImgPath = '';
        var MultipleImagePath = 'N/A';
        if(md.MultipleImageName.length>0){
            var bucketFolder = process.env.S3_BUCKET_NAME;
            var subdir = id;
            var imageFolder = bucketFolder + '/' + subdir +'/MoreImages';
            var bucket = new AWS.S3({
                params: {
                    Bucket: imageFolder
                }
            });
            for(var i = 0; i < md.MultipleImageName.length;i++){
                
                multipleImg = new Buffer(md.MultipleImage[i].replace(/^data:image\/\w+;base64,/, ""),'base64');
                var imgname = currentdate+md.MultipleImageName[i];
                var contentToPost = {
                    Key:  imgname, 
                    Body: multipleImg,
                    ACL: 'public-read',
                    ContentEncoding: 'base64'
                };
                if(MultipleImagePath!='N/A'){
                    MultipleImagePath = MultipleImagePath+ ','+imgname;
                } else {
                    MultipleImagePath = imgname;
                }
                bucket.putObject(contentToPost, function (error, data) {
                    if (error) {
                        //console.log("Error in posting Content [" + error + "]");
                        return false;
                    } 
                    else {
                        //console.log(data);
                    } 
                })
                .on('httpUploadProgress',function (progress) {
                    //console.log(Math.round(progress.loaded / progress.total * 100) + '% done');
                });
            }
        }
        //console.log(md.MultipleVideo);
        var VideoPath = 'N/A';
        var video_data = [];
        var videos = md.MultipleVideo;
        videos.forEach(function(vdata) {
            if(vdata["videolink"]!=''){
                var temp_data = {
                    "M": {
                        "videolink": {
                            "S": vdata["videolink"]
                        }
                    }
                }
                video_data.push(temp_data);
            }
        }); 

        var params = {
            TableName: TableName,
            Item:{
                Id : { S : id },
                //ContestMasterId : { S : ContestMasterId},
                UserId : { S : md.UserId },
                OrganizerName : { S : md.OrganizerName },
                ContestName :{ S : md.ContestName },
                Category : { S : md.Category },
                SubCategory : { S : md.SubCategory },
                Description : { S : Discription },
                RulesAndRegulation : { S : RulesAndRegulation },
                Judgus : { S : Judges },
                Prizes : { S : Prizes },
                Con_Status : { S : md.Con_Status },
                ContestType :  { S : md.ContestType },
                AwardCeremony : { S : AwardCeremony },
                Country : { S : md.Country },
                DeadlineDateTime : { N : md.DeadlineDateTime},
                ContestFromDateTime : { N : md.ContestFromDateTime},
                ContestToDateTime : { N : md.ContestToDateTime },
                ResultDateTime : { N : md.ResultDateTime },
                PublishDateTime : { N : md.PublishDateTime },
                AcceptAfterDeadline : { S : md.AcceptAfterDeadline },
                VenueLetitude : { N : md.VenueLetitude.toString() },
                VenueLongitude : { N : md.VenueLongitude.toString() },
                Address : { S : Address },
                IsFree : { S : md.IsFree },
                Groups: { L : group_data },
                ContestImage: { S : ContestImagePath },
                MultipleImage: { S : MultipleImagePath },
                VideoPath: { L : video_data},
                CreatedDate : { N : currentdate },
                ModifiedDate : { N : currentdate },
            }
        };

        dynamodb.putItem(params, function(err, data) {
            if (err) {
                console.log(err);
                utility.successResponse(res, 'error', err);
                //utility.errorlog(err.stack,'contest','contest_create',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', id)
            }
        });
    } catch (err) {
        console.log(err);
        
        //utility.errorlog(err,'contest','contest_create',JSON.stringify(req.body));
    }
}
exports.contest_update = (req, res) => {
    try {
        const id = uuid.v1();
        md = req.body;
        //console.log(md);
        if (!md.ContestName) {
            return utility.errorResponse(res, 'No ContestName provided.',null);
        }
        if (!md.Category) {
            return utility.errorResponse(res, 'No Category provided.',null);
        }
        if (!md.SubCategory) {
            return utility.errorResponse(res, 'No SubCategory provided.',null);
        }
        var Discription = md.Discription;
        if (md.Discription=='') {
            Discription = "N/A";
        }
        var RulesAndRegulation = md.RulesAndRegulation;
        if (md.RulesAndRegulation=='') {
            RulesAndRegulation = "N/A";
        }
        var Judges = md.Judges;
        if (md.Judges=='') {
            Judges = "N/A";
        }
        var Prizes = md.Prizes;
        if (md.Prizes=='') {
            Prizes = "N/A";
        }
        var AwardCeremony = md.AwardCeremony;
        if (md.AwardCeremony=='') {
            AwardCeremony = "N/A";
        }
        var Address = md.Address;
        if (md.Address=='') {
            Address = "Hong Kong";
        }
        if (!md.ContestStartDate) {
            return utility.errorResponse(res, 'No ContestStartDate provided.',null);
        }
        if (!md.ContestStartTime) {
            return utility.errorResponse(res, 'No ContestStartTime provided.',null);
        }
        if (!md.ContestEndDate) {
            return utility.errorResponse(res, 'No ContestEndDate provided.',null);
        }
        if (!md.ContestEndTime) {
            return utility.errorResponse(res, 'No ContestEndTime provided.',null);
        }

        if (!md.DeadlineDate) {
            return utility.errorResponse(res, 'No DeadlineDate provided.',null);
        } 

        if (!md.DeadlineTime) {
            return utility.errorResponse(res, 'No DeadlineTime provided.',null);
        }
        if (!md.AcceptAfterDeadline) {
            return utility.errorResponse(res, 'No AcceptAfterDeadline provided.',null);
        }
        
        if (!md.ResultDate) {
            return utility.errorResponse(res, 'No ResultDate provided.',null);
        }
        if (!md.ResultTime) {
            return utility.errorResponse(res, 'No ResultTime provided.',null);
        }
        if (!md.PublishDate) {
            return utility.errorResponse(res, 'No PublishDate provided.',null);
        }
        if (!md.PublishTime) {
            return utility.errorResponse(res, 'No PublishTime provided.',null);
        }
        if (!md.Country) {
            return utility.errorResponse(res, 'No Country provided.',null);
        }
        if (!md.MultipleVideo) {
            return utility.errorResponse(res, 'No Video provided.',null);
        }
        
        
        var ContestFromDate = dateformate(md.ContestStartDate);
        var ContestFromTime = dateformatewithtime(md.ContestStartTime);
        var ContestFromDateTime = new Date(ContestFromDate+ ' ' + ContestFromTime ).getTime().toString();
        
        var ContestToDate = dateformate(md.ContestEndDate);
        var ContestToTime = dateformatewithtime(md.ContestEndTime);
        var ContestToDateTime = new Date(ContestToDate+ ' ' + ContestToTime ).getTime().toString();
        var CompareEnddatetime = new Date(ContestToDate+ ' ' + ContestToTime ).getTime();
        // if(ContestToDateTime<ContestFromDateTime){
        //     return utility.errorResponse(res, 'Please Enter EndDate Greater Than StartDate.',null);
        // }
        var ResultDate = dateformate(md.ResultDate);
        var ResultTime = dateformatewithtime(md.ResultTime);
        var ResultDateTime = new Date(ResultDate+ ' ' + ResultTime ).getTime().toString();
        if(md.ResultDate!='' && md.ContestEndDate!=''){
            if(new Date(md.ResultDate) < new Date(md.ContestEndDate)){
                return utility.errorResponse(res, 'Please Enter Valid Result Date.',null);
            }
        }

        var PublishDate = dateformate(md.PublishDate);
        var PublishTime = dateformatewithtime(md.PublishTime);
        var PublishDateTime = new Date(PublishDate+ ' ' + PublishTime ).getTime().toString();
        if(md.PublishDate!='' && md.ContestStartDate!=''){
            if(new Date(md.PublishDate) > new Date(md.ContestStartDate)){
                return utility.errorResponse(res, 'Please Enter Valid Publish Date.',null);
            }
        }

        var DeadlineDate = dateformate(md.DeadlineDate);
        var DeadlineTime = dateformatewithtime(md.DeadlineTime);
        var DeadlineDateTime = new Date(DeadlineDate+ ' ' + DeadlineTime ).getTime().toString();
        var compareDeadlinedatetime  = new Date(DeadlineDate+ ' ' + DeadlineTime ).getTime();
        //console.log(CompareEnddatetime);
        //console.log(compareDeadlinedatetime);
        if(md.DeadlineDate!='' && md.ContestStartDate!=''){
            if(compareDeadlinedatetime > CompareEnddatetime){
                return utility.errorResponse(res, 'Please Enter Valid Deadline Date.',null);
            }
        }

        // if(md.PrefferedLang== 'en'){
        //     var TableName = process.env.CONTEST_TABLE;
        // } else if(md.PrefferedLang== 'tc') {
        //     var TableName = process.env.CONTEST_TABLE_TC;
        // } else {
        var TableName = process.env.CONTEST_TABLE;
        // }
        var group_data = [];
        var grpdata12 = md.Groups;
        grpdata12.forEach(function(grpdata) {
            var temp_data = {
                "M": {
                    "SubmissionType": {
                        "S": grpdata["SubmissionType"]
                    },
                    "NoOfParticipant": {
                        "N": grpdata["NoOfParticipant"]
                    },
                    "Gender": {
                        "S": grpdata["Gender"]
                    },
                    "GroupByAge": {
                        "B": grpdata["GroupByAge"]
                    },
                    "GroupAge": {
                        "S": grpdata["GroupAge"]
                    },
                    "Grade": {
                        "S": grpdata["Grade"]
                    },
                    "Fees": {
                        "S": grpdata["Fees"]
                    },
                    "TotalParticipant": {
                        "S": '0'
                    }
                }
            }
            group_data.push(temp_data);
        }); 
        
        var currentdate = new Date().getTime().toString();
        //console.log(md.SingleImage);
        //console.log(req.body.ContestId);
        
        if(md.ContestImage!=''){
            var singleImg = new Buffer(md.ContestImage.replace(/^data:image\/\w+;base64,/, ""),'base64');
            var bucketFolder = process.env.S3_BUCKET_NAME;
            var subdir = req.body.ContestId;
            var singleimgFolder = bucketFolder + '/' + subdir;
            var bucket = new AWS.S3({
                params: {
                    Bucket: singleimgFolder
                }
            });
            var imgname = currentdate+md.ContestImageName;
            var contentToPost = {
                Key: imgname, 
                Body: singleImg,
                ACL: 'public-read',
                ContentEncoding: 'base64'
            };
            //ContestImagePath = singleimgFolder+'/'+imgname;
            ContestImagePath = imgname;
            bucket.putObject(contentToPost, function (error, data) {
                if (error) {
                    //console.log("Error in posting Content [" + error + "]");
                    return false;
                } 
                else {
                    //console.log(data);
                } 
            })
            .on('httpUploadProgress',function (progress) {
                //console.log(Math.round(progress.loaded / progress.total * 100) + '% done');
            });

            var bucketInstance = new AWS.S3();
            var params = {
                Bucket: singleimgFolder,
                Key: md.SingleImage
            };
            bucketInstance.deleteObject(params, function (err, data) {
                if (data) {
                    console.log("File deleted successfully");
                }
                else {
                    console.log("Check if you have sufficient permissions : "+err);
                }
            });
        } else {
            ContestImagePath = md.SingleImage;
        }
        //var MultImgPath = '';
        var MultipleImagePath = 'N/A';
        if(md.MultipleImageName.length>0){
            var bucketFolder = process.env.S3_BUCKET_NAME;
            var subdir = req.body.ContestId;
            var imageFolder = bucketFolder + '/' + subdir +'/MoreImages';
            var bucket = new AWS.S3({
                params: {
                    Bucket: imageFolder
                }
            });
            for(var i = 0; i < md.MultipleImageName.length;i++){
                
                var updatemultipleImg = new Buffer(md.MultipleImage[i].replace(/^data:image\/\w+;base64,/, ""),'base64');
                var updateimgname = currentdate+md.MultipleImageName[i];
                var contentToPost = {
                    Key:  updateimgname, 
                    Body: updatemultipleImg,
                    ACL: 'public-read',
                    ContentEncoding: 'base64'
                };
                if(MultipleImagePath!='N/A'){
                    MultipleImagePath = MultipleImagePath+ ','+updateimgname;
                } else {
                    if(md.AllImage!=null){
                        if(md.AllImage!='N/A'){
                            if(md.AllImage!=''){
                                MultipleImagePath = md.AllImage+','+updateimgname;
                            } else {
                                MultipleImagePath = updateimgname;
                            }
                        } else {
                            MultipleImagePath = updateimgname;
                        }
                    } else {
                        MultipleImagePath = updateimgname;
                    }
                }
                bucket.putObject(contentToPost, function (error, data) {
                    if (error) { return false; } 
                    else {} 
                })
                .on('httpUploadProgress',function (progress) {
                    //console.log(Math.round(progress.loaded / progress.total * 100) + '% done');
                });
            }
        } else {
            if(md.AllImage!=null){
                if(md.AllImage!=''){
                    MultipleImagePath = md.AllImage;
                } else {
                    MultipleImagePath ='N/A';    
                }
            } else {
                MultipleImagePath ='N/A';
            }
        }
        if(md.DeleteImg!=null){
            if(md.DeleteImg.length>0){
                for(j=0; j < md.DeleteImg.length; j++){
                    var bucketFolder = process.env.S3_BUCKET_NAME;
                    var subdir = req.body.ContestId;
                    var imageFolder = bucketFolder + '/' + subdir +'/MoreImages';
                    var bucketInstance = new AWS.S3();
                    var params = {
                        Bucket: imageFolder,
                        Key: md.DeleteImg[j]
                    };
                    bucketInstance.deleteObject(params, function (err, data) {
                        if (data) {
                            console.log("File deleted successfully");
                        }
                        else {
                            console.log("Check if you have sufficient permissions : "+err);
                        }
                    });
                }
            }
        }
        var video_data = [];
        var videos = md.MultipleVideo;
        videos.forEach(function(vdata) {
            if(vdata["videolink"]!=''){
                var temp_data = {
                    "M": {
                        "videolink": {
                            "S": vdata["videolink"]
                        }
                    }
                }
                video_data.push(temp_data);
            }
        }); 

        var params = {
            Key: {
                Id : { S:req.body.ContestId}
            },
            TableName: TableName,
            UpdateExpression: "set ContestName = :ContestName,OrganizerName = :OrganizerName,Category = :Category,SubCategory = :SubCategory,Description = :Description,RulesAndRegulation = :RulesAndRegulation,Judgus = :Judgus,Prizes = :Prizes,AwardCeremony = :AwardCeremony,Country = :Country,DeadlineDateTime = :DeadlineDateTime,ContestFromDateTime = :ContestFromDateTime,ContestToDateTime = :ContestToDateTime,ResultDateTime = :ResultDateTime,PublishDateTime = :PublishDateTime,AcceptAfterDeadline = :AcceptAfterDeadline,Address = :Address,ContestImage= :ContestImage,MultipleImage= :MultipleImage, VideoPath=:VideoPath, VenueLetitude = :VenueLetitude,VenueLongitude = :VenueLongitude,Groups = :Groups",
            ExpressionAttributeValues:{
                ":ContestName" : { S: md.ContestName},
                ":OrganizerName" : { S: md.OrganizerName},
                ":Category" : { S : md.Category },
                ":SubCategory" : { S : md.SubCategory },
                ":Description" : { S : Discription },
                ":RulesAndRegulation" : { S : RulesAndRegulation },
                ":Judgus" : { S : Judges },
                ":Prizes" : { S : Prizes },
                ":AwardCeremony" : { S : AwardCeremony },
                ":Country" : { S : md.Country },
                ":DeadlineDateTime" : { N : md.DeadlineDateTime},
                ":ContestFromDateTime" : { N : md.ContestFromDateTime},
                ":ContestToDateTime" : { N : md.ContestToDateTime },
                ":ResultDateTime" : { N : md.ResultDateTime },
                ":PublishDateTime" : { N : md.PublishDateTime },
                ":AcceptAfterDeadline" : { S : md.AcceptAfterDeadline },
                ":Address": { S : md.Address },
                ":ContestImage": { S : ContestImagePath },
                ":MultipleImage": { S : MultipleImagePath },
                ":VideoPath": { L : video_data},
                ":VenueLetitude" : { N : md.VenueLetitude.toString() },
                ":VenueLongitude" : { N : md.VenueLongitude.toString() },
                ":Groups": { L : group_data }
            },
            ReturnValues:"UPDATED_NEW"
        };
        dynamodb.updateItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                //utility.errorlog(err.stack,'contest','contest_update',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data);
            }
        });
    } catch (err) {
        //utility.errorlog(err.stack,'contest','contest_update',JSON.stringify(req.body));
    }

    
}
exports.contest_get_all = (req, res) => {
    try {
        // //var prefLang = process.env.DEFAULT_LANGUAGE; //req.params.prefLang;
        // if(prefLang=='en' || prefLang == null){
        //     TableName = process.env.CONTEST_TABLE;
        // }
        // else(prefLang == 'tc')
        //     TableName = process.env.CONTEST_TABLE_TC;

        
        
        // var userlang = req.params.prefLang;
        // if(userlang=='' || userlang== 'null'){
        //     TableName = process.env.CONTEST_TABLE;
        // } else {
        //     if(userlang=='en' || userlang == 'null'){
        TableName = process.env.CONTEST_TABLE;
        //     } else {
        //         TableName = process.env.CONTEST_TABLE_TC;
        //     } 
        // }
        
        
        var currentdate = new Date().getTime();
        //var currentdate = new Date();
        
        //var date  = new Date(date);
        //console.log(currentdate);
        var docClient = new AWS.DynamoDB.DocumentClient();
        var params = {
            TableName: TableName,
            // KeyConditionExpression: "#st = :status and #dt = :Pdate",
            // ExpressionAttributeNames:{
            //     "#st": "Con_Status",
            //     "#dt": 'PublishDateTime'
            // },
            // ExpressionAttributeValues: {
            //     ":status": { S: 'Accepted' },
            //     ":Pdate": { N:'1541010600000'},
            // }
            //Limit: 10,
            FilterExpression: "Con_Status = :Con_Status AND PublishDateTime <= :PublishDateTime AND ContestToDateTime >= :ContestToDateTime",
            //FilterExpression: "Con_Status = :Con_Status",
            ExpressionAttributeValues: {
                ":Con_Status": { S: 'Accepted' },
                ":PublishDateTime": { N: currentdate.toString() },
                ":ContestToDateTime": { N: currentdate.toString() }
            },
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'contest','contest_get_all',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data.Items)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'contest','contest_get_all',JSON.stringify(req.body));
    }
	
}

exports.home_contest_list = (req, res) => {
    try {
        //console.log('12');
        TableName = process.env.CONTEST_TABLE;
        
        var currentdate = new Date().getTime();
        var docClient = new AWS.DynamoDB.DocumentClient();
        var params = {
            TableName: TableName,
            //Limit: 6,
            FilterExpression: "Con_Status = :Con_Status AND PublishDateTime <= :PublishDateTime",
            ExpressionAttributeValues: {
                ":Con_Status": { S: 'Accepted' },
                ":PublishDateTime": { N: currentdate.toString() }
            },
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'contest','contest_get_all',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data.Items)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'contest','contest_get_all',JSON.stringify(req.body));
    }
	
}

exports.contest_getby_id = (req, res) => {
    //console.log(req.params);
    try {
        // var prefLang = req.params.prefLang;
        // var TableName = process.env.CONTEST_TABLE_TC;
        // if(prefLang=='en'){
        //     TableName=process.env.CONTEST_TABLE;
        // }
        // var userlang = req.params.prefLang;
        // if(userlang=='' || userlang== 'null'){
        //     TableName = process.env.CONTEST_TABLE;
        // } else {
        //     if(userlang=='en' || userlang == 'null'){
        TableName = process.env.CONTEST_TABLE;
        //     } else {
        //         TableName = process.env.CONTEST_TABLE_TC;
        //     } 
        // }
        //console.log(TableName);
        
        var params = {
            TableName: TableName,
                Key: {
                    'Id' : {S: req.params.id},
                },
            };
        dynamodb.getItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'contest','contest_getby_id',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data);
                
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'contest','contest_getby_id',JSON.stringify(req.body));
    }
}
exports.contest_edit_getby_id = (req, res) => {
    //console.log(req.params);
    try {
        // var prefLang = req.params.prefLang;
        // var TableName = process.env.CONTEST_TABLE_TC;
        // if(prefLang=='en'){
        //     TableName=process.env.CONTEST_TABLE;
        // }
        // var userlang = req.params.prefLang;
        // if(userlang=='' || userlang== 'null'){
        //     TableName = process.env.CONTEST_TABLE;
        // } else {
        //     if(userlang=='en' || userlang == 'null'){
        TableName = process.env.CONTEST_TABLE;
        //     } else {
        //         TableName = process.env.CONTEST_TABLE_TC;
        //     } 
        // }
        //console.log(TableName);
        
        var params = {
            TableName: TableName,
                Key: {
                    'Id' : {S: req.params.id},
                },
            };
        dynamodb.getItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'contest','contest_getby_id',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'contest','contest_getby_id',JSON.stringify(req.body));
    }
}
exports.search_contest = (req, res) => {
    try {
        // var prefLang=req.query.prefLang;
        // var TableName = process.env.CONTEST_TABLE_TC;
        // if(prefLang=='en'){
        // TableName=process.env.CONTEST_TABLE;
        // }
        // var userlang = req.query.prefLang;
        // if(userlang=='' || userlang== 'null'){
        //     TableName = process.env.CONTEST_TABLE;
        // } else {
        //     if(userlang=='en' || userlang == 'null'){
        TableName = process.env.CONTEST_TABLE;
        //     } else {
        //         TableName = process.env.CONTEST_TABLE_TC;
        //     } 
        // }
        //console.log(TableName);
        var Category=req.query.category;
        var SubCategory=req.query.subcategory;
        //console.log(SubCategory);
        var Contest=req.query.contest;
        var Country=req.query.country;
        var Price=req.query.price;
        var Contestname=req.query.contestname;
        var qry = '';
        var qryval = '';
        
        var currentdate = new Date().getTime();

        var filterExpression =  ""; 
        var expressionAttributeValues = {};
        var contentIdName = ":PublishDateTime";
        filterExpression = 'PublishDateTime<='+ contentIdName;
        expressionAttributeValues[contentIdName] ={ N: currentdate.toString()};
        
        var contentIdName = ":Con_Status";
        var StatusExpression = '';
        StatusExpression = 'Con_Status='+ contentIdName;
        
        expressionAttributeValues[contentIdName] ={ S: 'Accepted'};
        if(filterExpression!=''){
            filterExpression=filterExpression+' AND '+StatusExpression;
        }else {
            filterExpression=filterExpression+StatusExpression;
        }
        
        var countryExpression = '';
        if(Country!='undefined'){
            var contentIdName = ":Country";
            countryExpression = 'Country='+ contentIdName;
        
            expressionAttributeValues[contentIdName] ={ S: Country};
        }
        // if(countryExpression!=''){
        //     filterExpression=filterExpression+' AND '+catfilterexp;;
        // }
        //console.log(filterExpression);
        if(countryExpression!=''){
            //console.log(countryExpression);
            if(filterExpression!=''){
                filterExpression=filterExpression+' AND '+countryExpression;
            }else {
                filterExpression=filterExpression+countryExpression;
            }
        }
        //console.log(filterExpression);
        catfilterexp ='';
        if(Category!='undefined'){
            categoryarr = Category.split(',');
            catfilterexp = '(';
            for(i=0; i < categoryarr.length; i++){
                var contentIdName = ":Category"+(i+1);
                if (i==0) {
                    catfilterexp = catfilterexp +'contains (Category,'+ contentIdName+')';
                } else {
                    catfilterexp = catfilterexp + " OR " +'contains (Category,'+ contentIdName+')';
                }
                expressionAttributeValues[contentIdName] ={ S: categoryarr[i]};
            }
            catfilterexp =catfilterexp +')';
        }
    
    //console.log(catfilterexp);
        if(catfilterexp!=''){
            if(filterExpression!=''){
                filterExpression=filterExpression+' AND '+catfilterexp;
            }else {
                filterExpression=filterExpression+catfilterexp;
            }
        }
        subcatfilterexp ='';
        if(SubCategory!=null){
            subcategoryarr = SubCategory.split(',');
            subcatfilterexp = '(';
            for(i=0; i < subcategoryarr.length; i++){
                var contentIdName = ":SubCategory"+(i+1);
                if (i==0) {
                    subcatfilterexp = subcatfilterexp +'contains (SubCategory,'+ contentIdName+')';
                } else {
                    subcatfilterexp = subcatfilterexp + " OR " +'contains (SubCategory,'+ contentIdName+')';
                }
                expressionAttributeValues[contentIdName] ={ S: subcategoryarr[i]};
            }
            subcatfilterexp =subcatfilterexp +')';
        }
        if(subcatfilterexp!=''){
            if(filterExpression!=''){
                filterExpression=filterExpression+' AND '+subcatfilterexp;
            }else {
                filterExpression=filterExpression+subcatfilterexp;
            }
        }

        contestfilterexp = '';
        if(Contest!='undefined'){
            var contentIdName = ":Contest";
            contestfilterexp = ' Id='+ contentIdName;
        
            expressionAttributeValues[contentIdName] ={ S: Contest};
        }
        //console.log(contestfilterexp);
        //console.log(expressionAttributeValues);
        if(contestfilterexp!=''){
            if(filterExpression!=''){
                filterExpression=filterExpression+' AND '+contestfilterexp;
            }else {
                filterExpression=filterExpression+contestfilterexp;
            }
        }
        
        pricfilterexp ='';
        if(Price!=null){
            pricearr = Price.split(',');
            pricfilterexp = '(';
            for(i=0; i < pricearr.length; i++){
                var contentIdName = ":IsFree"+(i+1);
                if (i==0) {
                    pricfilterexp = pricfilterexp +'contains (IsFree,'+ contentIdName+')';
                } else {
                    pricfilterexp = pricfilterexp + " OR " +'contains (IsFree,'+ contentIdName+')';
                }
                expressionAttributeValues[contentIdName] ={ S: pricearr[i]};
            }
            pricfilterexp =pricfilterexp +')';
        }
        if(pricfilterexp!=''){
            if(filterExpression!=''){
                filterExpression=filterExpression+' AND '+pricfilterexp;
            }else {
                filterExpression=filterExpression+pricfilterexp;
            }
        }

        textfilterexp ='';
        if(Contestname!=null){
            //textfilterexp = '(';
            //console.log(Contestname);
            if(Contestname!='undefined'){
                var ContestName = ":ContestName";
                textfilterexp = 'contains (ContestName,'+ ContestName+')';
                expressionAttributeValues[ContestName] ={ S: Contestname};
            }
            //textfilterexp =textfilterexp +')';
        }
    
    //console.log(textfilterexp);
        if(textfilterexp!=''){
            if(filterExpression!=''){
                filterExpression=filterExpression+' AND '+textfilterexp;
            }else {
                filterExpression=filterExpression+textfilterexp;
            }
        }

        //console.log(filterExpression);
        //console.log(expressionAttributeValues);
        var params = '';
        if(filterExpression==''){
            params = {
                TableName: TableName
            };
        } else {
            params = {
                TableName: TableName,
                ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
                FilterExpression: filterExpression, //"Category = :Category",
                //ProjectionExpression: "Name",
            };
        }
        
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'contest','search_contest',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data.Items);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'contest','search_contest',JSON.stringify(req.body));
    }
    
}

exports.contest_changestatus = (req, res) => {
    try {
    //console.log(req.body);

        md = req.body;
        //console.log(md.ContestType);
        //var PublishDate = dateformate(md.PublishDate);
        //var PublishTime = dateformatewithtime(md.PublishTime);
        //var PublishDateTime = new Date(PublishDate+ ' ' + PublishTime ).getTime().toString();

        var prefLang = md.ContestLang;
        // var TableName = process.env.CONTEST_TABLE_TC;
        // if(prefLang=='en'){
        var TableName=process.env.CONTEST_TABLE;
        // }
        //console.log(TableName);
        var params = {
            Key: {
                Id : { S:md.ContestId}
            },
            TableName: TableName,
            UpdateExpression: "set Con_Status = :Con_Status,ContestType = :ContestType,PublishDateTime= :PublishDateTime",
            ExpressionAttributeValues:{
                ":Con_Status" : { S:md.Status },
                ":ContestType" : { S:md.ContestType },
                ":PublishDateTime" : { N : md.PublishDateTime },
            },
            ReturnValues:"ALL_NEW"
        };
        dynamodb.updateItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'contest','contest_changestatus',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data);
                //utility.successResponse(res, 'Success', data.Attributes);
                // if(prefLang=='tc'){
                //     if(data.Attributes.ContestMasterId.S=='0'){
                //         var params = {
                //             TableName: process.env.CONTEST_TABLE,
                //             FilterExpression: "ContestMasterId = :Id",
                //             ExpressionAttributeValues: {
                //                 ":Id": { S: md.ContestId}
                //             },
                //             ProjectionExpression: "Id",
                //         };
                //         dynamodb.scan(params, function(err, data) {
                //             if (err) {
                //                 utility.errorResponse(res, 'error', err);
                //                 utility.errorlog(err.stack,'user','get_user_detail_by_id',JSON.stringify(req.body));
                //             } else {
                //                 //console.log(data);
                //                 //utility.successResponse(res, 'Success',data.Items[0].Id.S);
                //                 if(data.Items!=null){
                //                     //console.log(data.Items[0]!=null);
                //                     if(data.Items[0]!=null){
                //                         var params = {
                //                             Key: {
                //                                 Id : { S : data.Items[0].Id.S}
                //                             },
                //                             TableName: process.env.CONTEST_TABLE,
                //                             UpdateExpression: "set Con_Status = :Con_Status",
                //                             ExpressionAttributeValues:{
                //                                 ":Con_Status" : { S:md.Status },
                //                             },
                //                             ReturnValues:"ALL_NEW"
                //                         };
                //                         dynamodb.updateItem(params, function(err, data) {
                //                             if (err) {
                //                                 utility.errorResponse(res, 'error', err);
                //                                 utility.errorlog(err.stack,'contest','contest_changestatus',JSON.stringify(req.body));
                //                             } else {
                //                                 utility.successResponse(res, 'Success', data);
                //                             }
                //                         });
                //                     } else {
                //                         utility.successResponse(res, 'Success', data);
                //                     }
                //                 } else {
                //                     utility.successResponse(res, 'Success', data);
                //                 }
                //             }
                //         });
                //     } else {
                //         utility.successResponse(res, 'Success', data);
                //     }
                // } else {
                //     utility.successResponse(res, 'Success', data);
                // }
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'contest','contest_changestatus',JSON.stringify(req.body));
    }
}

exports.contest_get_all_client = (req, res) => {
    try {
    //    var userlang = req.params.prefLang;
    //     if(userlang=='' || userlang== 'null'){
    //         TableName = process.env.CONTEST_TABLE;
    //     } else {
    //         if(userlang=='en' || userlang == 'null'){
    TableName = process.env.CONTEST_TABLE;
    //         } else {
    //             TableName = process.env.CONTEST_TABLE_TC;
    //         } 
    //     }
        //console.log(TableName);
        var params = {
            TableName: TableName,
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'contest','contest_get_all_client',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'contest','contest_get_all_client',JSON.stringify(req.body));
    }
	
}

// exports.add_subscribe_user = (req, res) => {
//     try {
//         md = req.body;
//         console.log(md);
        
//         var currentdate = new Date().getTime();  
//         var grpdata12 = md.Groups;
//         const CommomId = uuid.v1();
//         //var ParticipentTable = process.env.ParticipentPaymentMaster_QA
//         grpdata12.forEach(function(grpdata) {
//             const id = uuid.v1();
//             var params = {
//                 TableName: process.env.TRANSACTION,
//                 Item:{
//                     Id : { S : id },
//                     TransactionId :{ S : md.PaypalToken },
//                     ContestId : { S : md.ContestId },
//                     ContestName : { S : md.ContestName },
//                     ContestType : { S : md.ContestType },
//                     CommomId: { S : CommomId},
//                     ParentId :{ S : md.ParentId },
//                     ParentName :{ S : md.ParentName },
//                     ParentEmail :{ S : md.ParentEmail },
//                     ParentPhoneNumber :{ S : md.ParentPhoneNumber },
//                     ChildId : { S : grpdata["ChildId"] },
//                     ChildName : { S : grpdata["ChildName"] },
//                     ChildBirthDay : { S : grpdata["ChildBirthDay"] },
//                     ChildGender : { S : grpdata["ChildGender"] },
//                     SubmissionType: { S : grpdata["SubmissionType"] },
//                     TotalPayment : { S : md.TotalPayment },
//                     IndividualPayment : { S : grpdata["IndividualPayment"] },
//                     CreatedDate : { N : currentdate.toString() },
//                 }
//             };

//             dynamodb.putItem(params, function(err, data) {
//                 if (err) {
//                     utility.errorResponse(res, 'error', err);
//                     utility.errorlog(err.stack,'user','add_subscribe_user',JSON.stringify(req.body));
//                 } else {
//                     if(md.ContestType=='en'){
//                         TableName = process.env.CONTEST_TABLE;
//                     } else {
//                         TableName = process.env.CONTEST_TABLE_TC;
//                     }
//                     //console.log(TableName);
                    
//                     var params = {
//                         TableName: TableName,
//                             Key: {
//                                 'Id' : {S: md.ContestId},
//                             },
//                         };
//                     dynamodb.getItem(params, function(err, data) {
//                         if (err) {
//                             utility.errorResponse(res, 'error', err);
//                             utility.errorlog(err.stack,'contest','contest_getby_id',JSON.stringify(req.body));
//                         } else {
//                             var arr = data.Item.Groups.L;
//                             var group_data = [];
//                             var grpdata12 = data.Item.Groups.L;
//                             console.log(grpdata12);
//                             grpdata12.forEach(function(gropdata) {
//                                 console.log(gropdata);
                                
//                                 console.log(gropdata.M.SubmissionType.S);
//                                 if(gropdata.M.TotalParticipant!=null){
//                                     if(gropdata.M.SubmissionType.S==grpdata["SubmissionType"]){
//                                         var total = parseInt(gropdata.M.TotalParticipant.S)+1;
//                                     } else {
//                                         var total = gropdata.M.TotalParticipant.S;
//                                     }
//                                 } else {
//                                     var total = '1';
//                                 }
//                                 console.log(total);
//                                 var temp_data = {
//                                     "M": {
//                                         "SubmissionType": {
//                                             "S": gropdata.M.SubmissionType.S
//                                         },
//                                         "NoOfParticipant": {
//                                             "N": gropdata.M.NoOfParticipant.N
//                                         },
//                                         "Gender": {
//                                             "S": gropdata.M.Gender.S
//                                         },
//                                         "GroupByAge": {
//                                             "B": gropdata.M.GroupByAge.B
//                                         },
//                                         "GroupAge": {
//                                             "S": gropdata.M.GroupAge.S
//                                         },
//                                         "Grade": {
//                                             "S": gropdata.M.Grade.S
//                                         },
//                                         "Fees": {
//                                             "S": gropdata.M.Fees.S
//                                         },
//                                         "TotalParticipant": {
//                                             "S": total.toString()
//                                         }
//                                     }
//                                 }
//                                 group_data.push(temp_data);
//                             }); 

//                             var params = {
//                                 Key: {
//                                     Id : { S:md.ContestId}
//                                 },
//                                 TableName: TableName,
//                                 UpdateExpression: "set Groups = :Groups",
//                                 ExpressionAttributeValues:{
//                                     ":Groups": { L : group_data }
//                                 },
//                                 ReturnValues:"UPDATED_NEW"
//                             };
//                             dynamodb.updateItem(params, function(err, data) {
//                                 if (err) {
//                                     utility.errorResponse(res, 'error', err);
//                                     utility.errorlog(err.stack,'contest','contest_update',JSON.stringify(req.body));
//                                 } else {
//                                     utility.successResponse(res, 'Success', data);
//                                 }
//                             });
                            
//                             //utility.successResponse(res, 'Success', data);
//                             //console.log(arr)
//                         }
//                     });
                    
//                     //utility.successResponse(res, 'Success', data);
//                     // if(md.TotalPayment!=''){
//                     //     const PaymentId = uuid.v1();
//                     //     //utility.successResponse(res, 'Success', data);
//                     //     var params = {
//                     //         TableName: process.env.PARTICIPANT_PAYMENT,
//                     //         Item:{
//                     //             Id : { S : PaymentId },
//                     //             ParticipentID : { S : id },
//                     //             PaypalToken :{ S : md.PaypalToken },
//                     //             TotalPayment : { S : md.TotalPayment },
//                     //             IndividualPayment : { S : grpdata["IndividualPayment"] },
//                     //             CreatedDate : { N : currentdate },
//                     //         }
//                     //     };
//                     //     dynamodb.putItem(params, function(err, data) {
//                     //         if (err) {
//                     //             utility.errorResponse(res, 'error2', err);
//                     //             utility.errorlog(err.stack,'user','add_user_payment',JSON.stringify(req.body));
//                     //         } else {
//                     //             utility.successResponse(res, 'Success', data);
//                     //         }
//                     //     });
//                     // } else {
//                     //     utility.successResponse(res, 'Success', data);
//                     // }
//                 }
//             });
//         });
//     } catch (err) {
//         utility.errorlog(err.stack,'contest','add_subscribe_user',JSON.stringify(req.body));
//     }
// }
// exports.get_subscribe_user = (req, res) => {
//     try {
//         md = req.body;
//         var filterExpression =  ""; 
//         var expressionAttributeValues = {};
//         var contentIdName = ":ContestId";
//         filterExpression = 'ContestId ='+ contentIdName;
//         expressionAttributeValues[contentIdName] ={ S: md.ContestId};
//         var params = {
//             TableName: process.env.TRANSACTION,
//             ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
//             FilterExpression: filterExpression,
//         };
//         dynamodb.scan(params, function(err, data) {
//             if (err) {
//                 utility.errorResponse(res, 'error', err);
//                 utility.errorlog(err.stack,'user','get_subscribe_user',JSON.stringify(req.body));
//             } else {
//                 utility.successResponse(res, 'Success1', data)
//             }
//         });
//     } catch (err) {
//         utility.errorlog(err.stack,'user','get_subscribe_user',JSON.stringify(req.body));
//     }
// }
// exports.get_participant_by_type = (req, res) => {
//     try {
//         md = req.body;
//         var filterExpression =  ""; 
//         var expressionAttributeValues = {};
//         var contentIdName = ":ContestId";
//         filterExpression = 'ContestId ='+ contentIdName;
//         expressionAttributeValues[contentIdName] ={ S: md.ContestId};

//         var contentIdName = ":SubmissionType";
//         var SubmissionType = '';
//         SubmissionType = 'SubmissionType='+ contentIdName;
//         expressionAttributeValues[contentIdName] ={ S: md.SubmissionType};

//         if(filterExpression!=''){
//             filterExpression=filterExpression+' AND '+SubmissionType;
//         }else {
//             filterExpression=filterExpression+SubmissionType;
//         }
//         //console.log(filterExpression);
//         var params = {
//             TableName: process.env.TRANSACTION,
//             ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
//             FilterExpression: filterExpression,
//         };
//         dynamodb.scan(params, function(err, data) {
//             if (err) {
//                 utility.errorResponse(res, 'error', err);
//                 utility.errorlog(err.stack,'user','get_participant_by_type',JSON.stringify(req.body));
//             } else {
//                 utility.successResponse(res, 'Success1', data)
//             }
//         });
//     } catch (err) {
//         utility.errorlog(err.stack,'user','get_participant_by_type',JSON.stringify(req.body));
//     }
// }

// exports.get_transation_details = (req, res) => {
//     try {
//         // md = req.body;
//         // var filterExpression =  ""; 
//         // var expressionAttributeValues = {};
//         // var contentIdName = ":ContestId";
//         // filterExpression = 'ContestId ='+ contentIdName;
//         // expressionAttributeValues[contentIdName] ={ S: md.ContestId};

//         // var contentIdName = ":SubmissionType";
//         // var SubmissionType = '';
//         // SubmissionType = 'SubmissionType='+ contentIdName;
//         // expressionAttributeValues[contentIdName] ={ S: md.SubmissionType};

//         // if(filterExpression!=''){
//         //     filterExpression=filterExpression+' AND '+SubmissionType;
//         // }else {
//         //     filterExpression=filterExpression+SubmissionType;
//         // }
//         //console.log(filterExpression);
//         var params = {
//             TableName: process.env.TRANSACTION,
//             //ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
//             //FilterExpression: filterExpression,
//         };
//         dynamodb.scan(params, function(err, data) {
//             if (err) {
//                 utility.errorResponse(res, 'error', err);
//                 utility.errorlog(err.stack,'user','get_transation_details',JSON.stringify(req.body));
//             } else {
//                 utility.successResponse(res, 'Success', data)
//             }
//         });
//     } catch (err) {
//         utility.errorlog(err.stack,'user','get_transation_details',JSON.stringify(req.body));
//     }
// }

// exports.payment_email = (req, res) => {
//     md = req.body;
//     readHTMLFile(__dirname + '/paymentemail.html', function(err, html) {
//         var template = handlebars.compile(html);
//         var replacements = {
//             name: md.Name,
//             Amount: md.Amount,
//             Date: md.Date,
//         };
//         var htmlToSend = template(replacements);
//         var mailOptions = {
//             from: process.env.SMTP_USER,
//             to : md.Email,
//             subject : 'Payment successfully',
//             html : htmlToSend
//             };
//         smtpTransport.sendMail(mailOptions, function (error, response) {
//             if (error) {
//                 console.log(error);
//                 callback(error);
//             }
//             if(response){
//                 console.log(response);
//             }
//         });
//     });
// }

exports.get_contest_address = (req, res) => {
    var API_KEY = process.env.GOOGLE_MAP_API;
    var BASE_URL = "https://maps.googleapis.com/maps/api/geocode/json?address=";
    md = req.body;
    var address = md.Address;

    var url = BASE_URL + address + "&key=" + API_KEY;

    request(url, function (error, response, body) {
        if (!error) {
            utility.successResponse(res, 'Success',response);
        } else {
            utility.errorResponse(res, 'error', error);
        }
    });
}
exports.contest_delete = (req, res) => {
    try {
        TableName=process.env.CONTEST_TABLE;
        var params = {
            Key: {
                Id : { S:req.params.id}
            },
            TableName: TableName
        };
        dynamodb.deleteItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'contest','contest_delete',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'contest','contest_delete',JSON.stringify(req.body));
    }
};
function dateformate(date){
    var date  = new Date(date);
    //date = date.setMinutes( date.getMinutes() + date.getTimezoneOffset() );
    var day = date.getDate();
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    var dt = year + '-' + (monthIndex+1) + '-' + day;
    return dt;
}
function dateformatewithtime(date){
    var date  = new Date(date);
    //var userTimezoneOffset = date.getTimezoneOffset() * 60000;
    //date = new Date(date.getTime() + userTimezoneOffset);
    var day = date.getDate();
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    var hour=date.getHours();
    var min=date.getMinutes();
    var sec  = date.getSeconds();
    sec = (sec < 10 ? "0" : "") + sec;
    min = pad(min,2);
    var dt = hour+':'+ min +':' + sec;
    return dt;
}

function pad(number, length) {
    var str = '' + number;
    while (str.length < length) {
        str = '0' + str;
    }
    return str;

}
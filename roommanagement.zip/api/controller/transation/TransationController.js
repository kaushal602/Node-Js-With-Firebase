
var express = require('express');
var modelCategory = require('../../model/Category');
var utility = require('../../Utility/Utility');
var VerifyToken = require('../../auth/VerifyToken');
const uuid = require('uuid');
var bcrypt = require('bcryptjs');
require('dotenv').config();

var request = require('superagent');
/****************** Email Code*********** */
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var handlebars = require('handlebars');
var fs = require('fs');
var readHTMLFile = function(path, callback) {
    fs.readFile(path, {encoding: 'utf-8'}, function (err, html) {
        if (err) {
            throw err;
            callback(err);
        }
        else {
            callback(null, html);
        }
    });
};
smtpTransport = nodemailer.createTransport(smtpTransport({
    service: 'gmail',
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_USER_PASS
    }
}));
 /******************* Email code End****************/

var AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.region,
  accessKeyId: process.env.aws_access_key_id,
  secretAccessKey: process.env.aws_secret_access_key,
  //endpoint: "http://192.168.1.26:8000/shell/"
});
var dynamodb = new AWS.DynamoDB();

exports.add_subscribe_user = (req, res) => {
    try {
        md = req.body;
        var currentdate = new Date().getTime();  
        var grpdata12 = md.Groups;
        const CommomId = uuid.v1();
        var itemsProcessed = 0;
        //var ParticipentTable = process.env.ParticipentPaymentMaster_QA
        grpdata12.forEach(function(grpdata) {
            
            const id = uuid.v1();
            var params = {
                TableName: process.env.TRANSACTION,
                Item:{
                    Id : { S : id },
                    TransactionId :{ S : md.PaypalToken },
                    ContestId : { S : md.ContestId },
                    ContestName : { S : md.ContestName },
                    ContestType : { S : md.ContestType },
                    CommomId: { S : CommomId},
                    ParentId :{ S : md.ParentId },
                    ParentName :{ S : md.ParentName },
                    ParentEmail :{ S : md.ParentEmail },
                    ParentPhoneNumber :{ S : md.ParentPhoneNumber },
                    ChildId : { S : grpdata["ChildId"] },
                    ChildName : { S : grpdata["ChildName"] },
                    ChildBirthDay : { S : grpdata["ChildBirthDay"] },
                    ChildGender : { S : grpdata["ChildGender"] },
                    SubmissionType: { S : grpdata["SubmissionType"] },
                    TotalPayment : { S : md.TotalPayment },
                    IndividualPayment : { S : grpdata["IndividualPayment"] },
                    CreatedDate : { N : currentdate.toString() },
                }
            };

            dynamodb.putItem(params, function(err, data) {
                if (err) {
                    utility.errorResponse(res, 'error', err);
                    utility.errorlog(err.stack,'user','add_subscribe_user',JSON.stringify(req.body));
                } else {
                    itemsProcessed++;
                    if(itemsProcessed === grpdata12.length) {
                        callback();
                    }
                }
            });
            

        });
        function callback () { 
            console.log('all done'); 
            utility.successResponse(res, 'Success', 'data');
        }
    } catch (err) {
        utility.errorlog(err.stack,'contest','add_subscribe_user',JSON.stringify(req.body));
    }
}

exports.update_grouptype_data = (req, res) => {
    md = req.body;
    var group_data = [];
    var grouptype = md.GroupType;
    //console.log(grouptype);
   // console.log(md.ContestId);
    var TableName = process.env.CONTEST_TABLE;
    grouptype.forEach(function(grpdata) {
        var temp_data = {
            "M": {
                "SubmissionType": {
                    "S": grpdata["SubmissionType"]
                },
                "NoOfParticipant": {
                    "N": grpdata["NoOfParticipant"]
                },
                "Gender": {
                    "S": grpdata["Gender"]
                },
                "GroupByAge": {
                    "B": grpdata["GroupByAge"]
                },
                "GroupAge": {
                    "S": grpdata["GroupAge"]
                },
                "Grade": {
                    "S": grpdata["Grade"]
                },
                "Fees": {
                    "S": grpdata["Fees"]
                },
                "TotalParticipant": {
                    "S": grpdata["TotalParticipant"].toString()
                }
            }
        }
        group_data.push(temp_data);
    }); 

    var params = {
        Key: {
            Id : { S:md.ContestId}
        },
        TableName: TableName,
        UpdateExpression: "set Groups = :Groups",
        ExpressionAttributeValues:{
            ":Groups": { L : group_data }
        },
        ReturnValues:"UPDATED_NEW"
    };
    dynamodb.updateItem(params, function(err, data) {
        if (err) {
            utility.errorResponse(res, 'error', err);
            utility.errorlog(err.stack,'contest','update_grouptype_data',JSON.stringify(req.body));
        } else {
            console.log('add-total');
            utility.successResponse(res, 'Success', data);
        }
    });
}

exports.get_subscribe_user = (req, res) => {
    try {
        md = req.body;
        var filterExpression =  ""; 
        var expressionAttributeValues = {};
        var contentIdName = ":ContestId";
        filterExpression = 'ContestId ='+ contentIdName;
        expressionAttributeValues[contentIdName] ={ S: md.ContestId};
        var params = {
            TableName: process.env.TRANSACTION,
            ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
            FilterExpression: filterExpression,
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_subscribe_user',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success1', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_subscribe_user',JSON.stringify(req.body));
    }
}
exports.get_participant_by_type = (req, res) => {
    try {
        md = req.body;
        var filterExpression =  ""; 
        var expressionAttributeValues = {};
        var contentIdName = ":ContestId";
        filterExpression = 'ContestId ='+ contentIdName;
        expressionAttributeValues[contentIdName] ={ S: md.ContestId};

        var contentIdName = ":SubmissionType";
        var SubmissionType = '';
        SubmissionType = 'SubmissionType='+ contentIdName;
        expressionAttributeValues[contentIdName] ={ S: md.SubmissionType};

        if(filterExpression!=''){
            filterExpression=filterExpression+' AND '+SubmissionType;
        }else {
            filterExpression=filterExpression+SubmissionType;
        }
        //console.log(filterExpression);
        var params = {
            TableName: process.env.TRANSACTION,
            ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
            FilterExpression: filterExpression,
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_participant_by_type',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success1', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_participant_by_type',JSON.stringify(req.body));
    }
}

exports.get_transation_details = (req, res) => {
    try {
        var params = {
            TableName: process.env.TRANSACTION,
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_transation_details',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_transation_details',JSON.stringify(req.body));
    }
}

exports.payment_email = (req, res) => {
    md = req.body;
    
    readHTMLFile(__dirname + '/paymentemail.html', function(err, html) {
        var template = handlebars.compile(html);
        var replacements = {
            name: md.Name,
            Amount: md.Amount,
            Date: md.Date,
            ContestTitle: md.ContestTitle,
            StartDate: md.StartDate,
            EndDate: md.EndDate,
            Address: md.Address,
            Description: md.Description,
            TodayDate: md.TodayDate,
            Baseurl: md.Baseurl,
            ContestId: md.ContestId,
        };
        var htmlToSend = template(replacements);
        var mailOptions = {
            from: process.env.SMTP_USER,
            to : md.Email,
            subject : 'Payment successfully',
            html : htmlToSend
            };
        smtpTransport.sendMail(mailOptions, function (error, response) {
            if (error) {
                //console.log(error);
                //callback(error);
            }
            if(response){
                //console.log(response);
            }
        });
    });
}


exports.contestlist = (req, res) => {
    try {
        TableName = process.env.CONTEST_TABLE;
        var ContestId=req.body.ContestId;
        //console.log(ContestId);
        var filterExpression =  ""; 
        var expressionAttributeValues = {};
        contestfilterexp ='';
        if(ContestId!='undefined'){
            contestidarr = ContestId;
            contestfilterexp = '';
            for(i=0; i < contestidarr.length; i++){
                var contentIdName = ":Id"+(i+1);
                if (i==0) {
                    contestfilterexp = contestfilterexp +'Id='+ contentIdName+'';
                } else {
                    contestfilterexp = contestfilterexp + " OR " +'Id='+ contentIdName;
                }
                expressionAttributeValues[contentIdName] ={ S: contestidarr[i]};
            }
            contestfilterexp =contestfilterexp;
        }
        if(contestfilterexp!=''){
            if(filterExpression!=''){
                filterExpression=filterExpression+' AND '+contestfilterexp;
            }else {
                filterExpression=filterExpression+contestfilterexp;
            }
        }
        console.log(expressionAttributeValues);
        console.log(filterExpression);
        params = {
            TableName: TableName,
            ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
            FilterExpression: filterExpression, //"Category = :Category",
            //ProjectionExpression: "Name",
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'contest','search_contest',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'contest','search_contest',JSON.stringify(req.body));
    }
}


exports.submited_contestlist = (req, res) => {
    try {
        md = req.body;
        var filterExpression =  ""; 
        var expressionAttributeValues = {};
        var contentIdName = ":ParentId";
        filterExpression = 'ParentId ='+ contentIdName;
        expressionAttributeValues[contentIdName] ={ S: md.UserId};
        var params = {
            TableName: process.env.TRANSACTION,
            ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
            FilterExpression: filterExpression,
            ProjectionExpression: "ContestId",
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','submited_contestlist',JSON.stringify(req.body));
            } else {
                //console.log(data.Items);
                if(data.Count>0){
                    //console.log(data.Items.length);
                    var myContestId = []; 
                    for(var i=0; i<data.Items.length; i++){
                        myContestId.push(data.Items[i].ContestId.S);
                    }
                    //console.log(myContestId);
                    contestidarr = myContestId;

                    var filterExpression =  ""; 
                    var expressionAttributeValues = {};
                    contestfilterexp ='';
                    contestfilterexp = '(';
                    for(i=0; i < contestidarr.length; i++){
                        var contentIdName = ":Id"+(i+1);
                        if (i==0) {
                            contestfilterexp = contestfilterexp +'contains (Id,'+ contentIdName+')';
                        } else {
                            contestfilterexp = contestfilterexp + " OR " +'contains (Id,'+ contentIdName+')';
                        }
                        expressionAttributeValues[contentIdName] ={ S: contestidarr[i]};
                    }
                    contestfilterexp =contestfilterexp +')';

                    if(contestfilterexp!=''){
                        if(filterExpression!=''){
                            filterExpression=filterExpression+' AND '+contestfilterexp;
                        }else {
                            filterExpression=filterExpression+contestfilterexp;
                        }
                    }
                    params = {
                        TableName: TableName,
                        ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
                        FilterExpression: filterExpression, //"Category = :Category",
                        //ProjectionExpression: "Name",
                    };

                    dynamodb.scan(params, function (err, data) {
                        if (err) {
                            utility.errorResponse(res, 'error', err);
                            utility.errorlog(err.stack,'contest','submited_contestlist',JSON.stringify(req.body));
                        } else {
                            //console.log(data);
                            utility.successResponse(res, 'Success', data);
                        }
                    });

                } else {
                    utility.successResponse(res, 'Success', data)
                }
            }
        });
        
    } catch (err) {
        utility.errorlog(err.stack,'contest','submited_contestlist',JSON.stringify(req.body));
    }
}

exports.contest_wise_participate_child = (req, res) => {
    try {
        md = req.body;
        var params = {
            TableName: process.env.TRANSACTION,
            FilterExpression: "ParentId = :ParentId AND ContestId = :ContestId",
            //FilterExpression: "Con_Status = :Con_Status",
            ExpressionAttributeValues: {
                ":ParentId": { S: md.ParentId },
                ":ContestId": { S: md.ContestId }
            },
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','contest_wise_participate_child',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
        
    } catch (err) {
        utility.errorlog(err.stack,'contest','contest_wise_participate_child',JSON.stringify(req.body));
    }
}
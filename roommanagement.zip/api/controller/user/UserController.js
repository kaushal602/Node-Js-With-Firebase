var express = require('express');
var utility = require('../../Utility/Utility');
var VerifyToken = require('../../auth/VerifyToken');
const uuid = require('uuid');
var jwt = require('jsonwebtoken');
//var bcrypt = require('bcryptjs');
var config = require('../../../config');
require('dotenv').config();

var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
//var handlebars = require('handlebars');
var fs = require('fs');
var readHTMLFile = function(path, callback) {
    fs.readFile(path, {encoding: 'utf-8'}, function (err, html) {
        if (err) {
            throw err;
            callback(err);
        }
        else {
            callback(null, html);
        }
    });
};
smtpTransport = nodemailer.createTransport(smtpTransport({
    service: 'gmail',
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_USER_PASS
    }
}));
var firebase = require('firebase');
require('firebase/auth');
require('firebase/database');
firebase.initializeApp({
    //databaseURL: 'https://*****.firebaseio.com',
    apiKey: "AIzaSyCgf-yHmKWtAHEHarlS7_rK0NSxnDTHfeo",
    authDomain: "my-first-project-282cd.firebaseapp.com",
    databaseURL: "https://my-first-project-282cd.firebaseio.com",
    projectId: "my-first-project-282cd",
    storageBucket: "my-first-project-282cd.appspot.com",
    messagingSenderId: "47841206284"
});
//const jwt = require('express-jwt');
//const jwks = require('jwks-rsa');
// var admin = require("firebase-admin");
// var serviceAccount = require("../../../ServiceAccountKey.json");
// admin.initializeApp({
//     credential: admin.credential.cert(serviceAccount),
//     databaseURL: "https://my-first-project-282cd.firebaseio.com"
// });
// const uid = 'some-uid';
// var db = admin.database();


exports.get_all_user = (req, res) => {
    console.log('132');
    var starCountRef = firebase.database().ref();
        starCountRef.on('value', function(snapshot) {
        //updateStarCount(postElement, snapshot.val());
        console.log(snapshot.val())
    });
}
exports.create_user = (req, res) => {
    md = req.body;
    var firstname = req.body.firstname;
    var lastname = req.body.lastname;
    var email = req.body.email;
    var password = req.body.password;
    var password2 = req.body.password2;
    var phonenumber = req.body.phonenumber;
    var address = req.body.address;
    var usertype = req.body.usertype;
    var isactive = req.body.isactive;
    var AdminId = req.body.adminid;

    var firstname = md.firstname;
    if (!firstname) {
        return utility.errorResponse(res, 'No FirstName provided.',null);
    }
    var lastname = md.lastname;
    if (!lastname) {
        return utility.errorResponse(res, 'No LastName provided.',null);
    }

    var email = md.email;
    if (!email) {
        return utility.errorResponse(res, 'No Email provided.',null);
    }
    var password = md.password;
    if (!password) {
        return utility.errorResponse(res, 'No Password provided.',null);
    }
    var password2 = md.password2;
    if (!password2) {
        return utility.errorResponse(res, 'No Password 2 provided.',null);
    }
    if(password!='' && password2!=''){
        if(password!=password2){
            return utility.errorResponse(res, 'Password Not natch.',null);
        }
    }
    
    firebase.auth().createUserWithEmailAndPassword(email, password)
    .then(userData => { 
        //console.log(userData.user.uid);
        var adminid = '0';
        
        var firebaseRef = firebase.database().ref('users/'+userData.user.uid);
        //var usersRef = firebaseRef.child("users");
        firebaseRef.set({
            UserId: userData.user.uid,
            Email: email,
            FirstName: firstname,
            LastName:lastname,
            PhoneNumber:phonenumber,
            Address:address,
            UserType:usertype,
            IsActive:isactive,
            AdminId:adminid
        });
        if(usertype=='Admin'){
            adminid = userData.user.uid;
        } else {
            adminid = AdminId;
        }
        firebaseRef.update({
            AdminId:adminid
        });
        utility.successResponse(res, 'Create User Successfully',userData.user.uid);
    })
    .catch(error => {   
        console.log(error);
        utility.successResponse(res, 'Error1',error);
    })
}
exports.user_login = (req, res) => {
    md = req.body;
    var email = req.body.email;
    var password = req.body.password;
   
    var email = md.email;
    if (!email) {
        return utility.errorResponse(res, 'No Email provided.',null);
    }
    var password = md.password;
    if (!password) {
        return utility.errorResponse(res, 'No Password provided.',null);
    }

    firebase.auth().signInWithEmailAndPassword(email, password).then((user) => {
       //console.log(user)
       var starCountRef = firebase.database().ref('users/'+user.user.uid);
            starCountRef.on('value', function(snapshot) {
            //updateStarCount(postElement, snapshot.val());
            console.log(snapshot.val());
            utility.successResponse(res, 'Success',snapshot.val());
        });
       
        //this.ErrorMsg = "Form Submit";
    }).catch(function(error) {
        console.log(error); 
        utility.successResponse(res, 'Error',error);
    });   
}

exports.user_update = (req, res) => {
    md = req.body;
    var userid = req.body.userid;
    var firstname = req.body.firstname;
    var lastname = req.body.lastname;
    var email = req.body.email;
    var phonenumber = req.body.phonenumber;
    var address = req.body.address;
   
    var firstname = md.firstname;
    if (!firstname) {
        return utility.errorResponse(res, 'No FirstName provided.',null);
    }
    var lastname = md.lastname;
    if (!lastname) {
        return utility.errorResponse(res, 'No LastName provided.',null);
    }

    var firebaseRef = firebase.database().ref();
    var usersRef = firebaseRef.child("users");
    usersRef.child(userid).update({
        FirstName: firstname,
        LastName:lastname,
        PhoneNumber:phonenumber,
        Address:address
    });
    var starCountRef = firebase.database().ref('users/'+userid);
        starCountRef.on('value', function(snapshot) {
        //updateStarCount(postElement, snapshot.val());
        console.log(snapshot.val());
        utility.successResponse(res, 'Success',snapshot.val());
    });
    //utility.successResponse(res, 'User Updated Successfully',userid);
}
exports.general_expense = (req, res) => {
    md = req.body;
    
    var userid = md.userid;

    var roomrent = md.roomrent;
    if (roomrent=='') {
        roomrent = 0;
    }
    var lightbill = md.lightbill;
    if (lightbill=='') {
        lightbill = 0;
    }
    var otherexp = md.otherexp;
    if (otherexp=='') {
        otherexp = 0;
    }
    var gasbill = md.gasbill;
    if (gasbill=='') {
        gasbill = 0;
    }
    var additionlexp = md.additionlexp;
    if (additionlexp=='') {
        additionlexp = 0;
    }
    var expenseyear = md.expenseyear;
    var expensemonth = md.expensemonth;
       
    var firebaseRef = firebase.database().ref('generalexpense/'+userid+'/'+expenseyear+'/'+expensemonth);
        firebaseRef.set({
            RoomRent: roomrent,
            LightBill: lightbill,
            GasBill: gasbill,
            OtherExp:otherexp,
            AdditionlExp:additionlexp,
            ExpenseYear:expenseyear,
            ExpenseMonth:expensemonth
        });
    var starCountRef = firebase.database().ref('generalexpense/'+userid+'/'+expenseyear+'/'+expensemonth);
    starCountRef.on('value', function(snapshot) {
        //console.log(snapshot.val());
        utility.successResponse(res, 'Success',snapshot.val());
    });
    //utility.successResponse(res, 'Create Expense Successfully',null);
}
exports.add_regular_expense = (req, res) => {
    md = req.body;
    
    var userid = md.userid;
    var adminid = md.adminid;
    var amountfrom = md.amountfrom;
    var othermember = md.othermember;
    //console.log(amountfrom);
    //console.log(othermember);
    
    
    var item = md.item;
    if (!item) {
        return utility.errorResponse(res, 'No Item provided.',null);
    }
    var amount = md.amount;
    if (!amount) {
        return utility.errorResponse(res, 'No Amount provided.',null);
    }
    var expensedate = md.date;
    if (!expensedate) {
        return utility.errorResponse(res, 'No date provided.',null);
    }
    var entrynumber = "";
    var possible = "ABCD0EFGHI1JKLM2NOP3QRS4TU5VWX6YZab7cdefgh8ijkl9mnopqr10stuvwxyz0123456789";
    for (var i = 0; i < 5; i++)
    entrynumber += possible.charAt(Math.floor(Math.random() * possible.length));
    
    var date  = new Date(expensedate);
    var curdate  = new Date();
    //date = date.setMinutes( date.getMinutes() + date.getTimezoneOffset() );
    var day = date.getDate();
    var month = date.getMonth()+1;
    var year = date.getFullYear();
    var dt = day + '-' + month + '-' + year;

    var curdate  = new Date();
    //date = date.setMinutes( date.getMinutes() + date.getTimezoneOffset() );
    var cday = curdate.getDate();
    var cmonth = curdate.getMonth()+1;
    var cyear = curdate.getFullYear();
    var cdt = cyear + '-' + cmonth + '-' + cday;
    var persionalamount = 0;
    if(othermember!=''){
        var array = othermember.split(',');
        persionalamount = amount/(array.length+1);
    } else {
        persionalamount = amount;
    }
    if(amountfrom=='Room'){
        if(othermember!=''){
            othermember = othermember+','+userid;
        } else {
            othermember = userid;
        }
        var array = othermember.split(',');
        //persionalamount = amount/(array.length+1);
        for(var i=0;i<array.length;i++){
            var debitamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+entrynumber+'/debitexpense/'+array[i]);
            debitamunt.set({
                Item: item,
                ExpenseDate: expensedate,
                Amount: persionalamount,
                Userid:userid,
                CreatedDate:cdt,
                EntryKey:entrynumber,
                CreatedBy:userid
            });
        }
        var creditamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+entrynumber);
        creditamunt.update({
            CreatedBy:userid,
            TotalAmount:amount
        });
    } else {
        if(othermember!=''){
            //othermember = othermember;
            var array = othermember.split(',');
            persionalamount = amount/(array.length+1);
            for(var i=0;i<array.length;i++){
                var debitamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+entrynumber+'/debitexpense/'+array[i]);
                debitamunt.set({
                    Item: item,
                    ExpenseDate: expensedate,
                    Amount: persionalamount,
                    Userid:array[i],
                    CreatedDate:cdt,
                    EntryKey:entrynumber,
                    CreatedBy:userid
                });
            }
        }
        var creditamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+entrynumber+'/creaditexpense/'+userid);
        creditamunt.set({
            Item: item,
            ExpenseDate: expensedate,
            Amount: persionalamount,
            Userid:userid,
            CreatedDate:cdt,
            EntryKey:entrynumber,
            CreatedBy:userid
        });
        var creditamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+entrynumber);
        creditamunt.update({
            CreatedBy:userid,
            TotalAmount:amount
        });
    }
    
    // if(othermember!=''){
        
    // }

    
    // var starCountRef = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+dt+'/'+userid);
    // starCountRef.on('value', function(snapshot) {
    //     //console.log(snapshot.val());
    //     utility.successResponse(res, 'Success',snapshot.val());
    // });
    utility.successResponse(res, 'Create Expense Successfully',null);
}

exports.update_regular_expense = (req, res) => {
    md = req.body;
    
    var userid = md.userid;
    var adminid = md.adminid;
    var amountfrom = md.amountfrom;
    var othermember = md.othermember;
    var expenseid = md.expenseid;   
    var item = md.item;
    if (!item) {
        return utility.errorResponse(res, 'No Item provided.',null);
    }
    var amount = md.amount;
    if (!amount) {
        return utility.errorResponse(res, 'No Amount provided.',null);
    }
    var expensedate = md.date;
    if (!expensedate) {
        return utility.errorResponse(res, 'No date provided.',null);
    }
    // var entrynumber = "";
    // var possible = "ABCD0EFGHI1JKLM2NOP3QRS4TU5VWX6YZab7cdefgh8ijkl9mnopqr10stuvwxyz0123456789";
    // for (var i = 0; i < 5; i++)
    // entrynumber += possible.charAt(Math.floor(Math.random() * possible.length));
    
    var date  = new Date(expensedate);
    var curdate  = new Date();
    //date = date.setMinutes( date.getMinutes() + date.getTimezoneOffset() );
    var day = date.getDate();
    var month = date.getMonth()+1;
    var year = date.getFullYear();
    var dt = day + '-' + month + '-' + year;

    var curdate  = new Date();
    //date = date.setMinutes( date.getMinutes() + date.getTimezoneOffset() );
    var cday = curdate.getDate();
    var cmonth = curdate.getMonth()+1;
    var cyear = curdate.getFullYear();
    var cdt = cyear + '-' + cmonth + '-' + cday;
    var persionalamount = 0;
    if(othermember!=''){
        var array = othermember.split(',');
        persionalamount = amount/(array.length+1);
    } else {
        persionalamount = amount;
    }
    if(amountfrom=='Room'){
        if(othermember!=''){
            othermember = othermember+','+userid;
        } else {
            othermember = userid;
        }
        var array = othermember.split(',');
        //persionalamount = amount/(array.length+1);
        for(var i=0;i<array.length;i++){
            var debitamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+expenseid+'/debitexpense/'+array[i]);
            debitamunt.set({
                Item: item,
                ExpenseDate: expensedate,
                Amount: persionalamount,
                Userid:userid,
                CreatedDate:cdt,
                EntryKey:expenseid,
                CreatedBy:userid
            });
        }
        var creditamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+expenseid);
        creditamunt.update({
            CreatedBy:userid,
            TotalAmount:amount
        });
    } else {
        if(othermember!=''){
            //othermember = othermember;
            var array = othermember.split(',');
            persionalamount = amount/(array.length+1);
            for(var i=0;i<array.length;i++){
                var debitamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+expenseid+'/debitexpense/'+array[i]);
                debitamunt.set({
                    Item: item,
                    ExpenseDate: expensedate,
                    Amount: persionalamount,
                    Userid:array[i],
                    CreatedDate:cdt,
                    EntryKey:expenseid,
                    CreatedBy:userid
                });
            }
        }
        var creditamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+expenseid+'/creaditexpense/'+userid);
        creditamunt.set({
            Item: item,
            ExpenseDate: expensedate,
            Amount: persionalamount,
            Userid:userid,
            CreatedDate:cdt,
            EntryKey:expenseid,
            CreatedBy:userid
        });
        var creditamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+expenseid);
        creditamunt.update({
            CreatedBy:userid,
            TotalAmount:amount
        });
        // var creditamunt = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+expenseid);
        // creditamunt.set({
        //     CreatedBy:userid
        // });
    }
    utility.successResponse(res, 'Create Expense Successfully',null);
}

exports.add_advance_expense = (req, res) => {
    md = req.body;
    
    var userid = md.userid;
    var adminid = md.adminid;

    var amount = md.amount;
    if (!amount) {
        return utility.errorResponse(res, 'No Amount provided.',null);
    }
    
    // date  = new Date(expensedate);
    var date  = new Date();
    //console.log(date);
    //date = date.setMinutes( date.getMinutes() + date.getTimezoneOffset() );
    var day = date.getDate();
    var month = date.getMonth()+1;
    var year = date.getFullYear();
    var dt = year + '-' + month + '-' + day;
    var firebaseRef = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/advanceexpense/'+userid);
        firebaseRef.set({
            Amount: amount,
            Userid:userid,
            CreatedDate:dt
        });
    var starCountRef = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/advanceexpense/'+userid);
    starCountRef.on('value', function(snapshot) {
        //console.log(snapshot.val());
        utility.successResponse(res, 'Success',snapshot.val());
    });
    //utility.successResponse(res, 'Create Expense Successfully',null);
}
exports.year_list = (req, res) => {
    md = req.body;
    var adminid = md.adminid;
    var starCountRef = firebase.database().ref('generalexpense/'+adminid);
    starCountRef.on('value', function(snapshot) {
        var years = [];
        snapshot.forEach(function(child) {
            var year = child.key;
            years.push(year);
            var keys = snapshot.key;
        });
        utility.successResponse(res, 'Success',years);
    });
}
exports.month_list = (req, res) => {
    md = req.body;
    var adminid = md.adminid;
    var year = md.year;
    var starCountRef = firebase.database().ref('generalexpense/'+adminid+'/'+year);
    starCountRef.on('value', function(snapshot) {
        var months = [];
        snapshot.forEach(function(child) {
            var month = child.key;
            months.push(month);
            var keys = snapshot.key;
        });
        utility.successResponse(res, 'Success',months);
    });
}

exports.month_creadit_expense_list = (req, res) => {
    md = req.body;
    var adminid = md.adminid;
    var userid = md.userid;
    var year = md.year;
    var month = md.month;
    var ref1 = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month);
    ref1.orderByChild('CreatedBy').equalTo(userid).once("value", function(snapshot) {
        var ids = [];
        snapshot.forEach(function(child) {
            var expenseid = child.key;
            ids.push(expenseid);
            var keys = snapshot.key;
        });
        console.log(ids);
        var expensevalue = [];
        var itemsProcessed = 0;
        for(var i=0; i<ids.length; i++){
            var starCountRef = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+ids[i]+'/creaditexpense/'+userid);
            starCountRef.on('value', function(snapshot) {
                if(snapshot.val()!=null){
                    expensevalue.push(snapshot.val())
                    console.log(snapshot.val());
                }
                itemsProcessed++;
                if(itemsProcessed === ids.length) {
                    callback();
                }
            });
        }
        //console.log(expensevalue);
        function callback () { 
            utility.successResponse(res, 'Success',expensevalue);
        }
        
    });
}
exports.month_debit_expense_list = (req, res) => {
    md = req.body;
    var adminid = md.adminid;
    var userid = md.userid;
    var year = md.year;
    var month = md.month;
    var ref1 = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month);
    ref1.orderByChild('CreatedBy').equalTo(userid).once("value", function(snapshot) {
        var ids = [];
        snapshot.forEach(function(child) {
            var expenseid = child.key;
            ids.push(expenseid);
            var keys = snapshot.key;            
        });
        console.log(ids);
        //console.log(ids[0]);
        var expensevalue = [];
        var itemsProcessed = 0;
        var debitexpensevalue = [];
        for(var i=0; i<ids.length; i++){
            var starCountRef = firebase.database().ref('generalexpense/'+adminid+'/'+year+'/'+month+'/'+ids[i]+'/debitexpense/'+userid);
            starCountRef.on('value', function(snapshot) {
                if(snapshot.val()!=null){
                    debitexpensevalue.push(snapshot.val())
                    //console.log(snapshot.val());
                }
                itemsProcessed++;
                if(itemsProcessed === ids.length) {
                    callback();
                }
            });
        }
        function callback () { 
            utility.successResponse(res, 'Success',debitexpensevalue);
        }
        
    });
}
exports.get_user_list = (req, res) => {
    md = req.body;
    var adminid = md.adminid;
    var userid = md.userid;
    var ref1 = firebase.database().ref('users');
    ref1.orderByChild('AdminId').equalTo(adminid).once("value", function(snapshot) {
        var ids = [];
        snapshot.forEach(function(child) {
            var uid = child.key;
            //console.log(uid);
            if(userid!=uid){
                ids.push(uid);
            }
           
        });
        //console.log(ids);
        var itemsProcessed = 0;
        var userdetails = [];
        for(var i=0; i<ids.length; i++){
            var starCountRef = firebase.database().ref('users/'+ids[i]);
            starCountRef.on('value', function(snapshot) {
                //.log(snapshot.val());
                if(snapshot.val()!=null){

                    userdetails.push(snapshot.val())
                    //console.log(snapshot.val());
                }
                itemsProcessed++;
                if(itemsProcessed === ids.length) {
                    callback();
                }
            });
        }
        function callback () { 
            utility.successResponse(res, 'Success',userdetails);
        }
        //snapshot.val();
        //var keys = snapshot.key;            
        //console.log(keys);
        //console.log(snapshot.val());
        //console.log(ids[0]);
        
    //utility.successResponse(res, 'Success',snapshot.val());
        
    });
}


var express = require('express');
var modelCategory = require('../../model/Category');
var utility = require('../../Utility/Utility');
require('dotenv').config();
var AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.region,
  accessKeyId: process.env.aws_access_key_id,
  secretAccessKey: process.env.aws_secret_access_key,
  //endpoint: "http://192.168.1.26:8000/shell/"
});
var dynamodb = new AWS.DynamoDB();

exports.subcategory_get_all = (req, res) => {
    try {
        //var md = modelCategory.requestCategory;
        md = req.body;
        //console.log(JSON.stringify(md,null,2));
        //res.send(req.params.id);
        var params = {
            TableName: process.env.SUBCATEGORY_TABLE,
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                //res.status(400).send("error: " + "\n" + JSON.stringify(err, undefined, 2));
            } else {
                utility.successResponse(res, 'Success',data.Items);
                //res.status(200).send("Category List: " + "\n" + JSON.stringify(data));
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'subcategory','subcategory_get_all',JSON.stringify(req.body));
    }
	
}
exports.subcategory_get_by_id = (req, res) => {
    try {
 //single get
        md = req.params;
        //console.log(md.id);
        var params = {
            TableName: process.env.SUBCATEGORY_TABLE,
            FilterExpression: "SubCategoryHashTag = :SubCategoryHashTag",
            ExpressionAttributeValues: {
                ":SubCategoryHashTag": { S: md.id}
            },
            //ProjectionExpression: "FirstName,LastName,Email,PhoneNumber",
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'category','category_get_all',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'category','category_get_all',JSON.stringify(req.body));
    }
}

exports.subcategory_get_by_category = (req, res) => {
    try {
 //single get
        //console.log(req.params.categoryhashtag);
        if(req.params.categoryhashtag!=null){
            var filterExpression =  ""; 
            var expressionAttributeValues = {};
            var contentIdName = ":IsActive";
            filterExpression = 'IsActive='+ contentIdName;
            expressionAttributeValues[contentIdName] ={ N: '1'};
            
            catfilterexp ='';
            if(req.params.language=='tc'){
                categoryarr = req.params.categoryhashtag.split(',');
                catfilterexp = '(';
                for(i=0; i < categoryarr.length; i++){
                    var contentIdName = ":CategoryHashTag_TC"+(i+1);
                    if (i==0) {
                        catfilterexp = catfilterexp +'contains (CategoryHashTag_TC,'+ contentIdName+')';
                    } else {
                        catfilterexp = catfilterexp + " OR " +'contains (CategoryHashTag_TC,'+ contentIdName+')';
                    }
                    expressionAttributeValues[contentIdName] ={ S: categoryarr[i]};
                }
                catfilterexp =catfilterexp +')';
                // var contentIdName = ":CategoryHashTag_TC";
                // filterExpression = 'CategoryHashTag_TC ='+ contentIdName;
                // expressionAttributeValues[contentIdName] ={ S: req.params.categoryhashtag};
            } else {
                categoryarr = req.params.categoryhashtag.split(',');
                catfilterexp = '(';
                for(i=0; i < categoryarr.length; i++){
                    var contentIdName = ":CategoryHashTag"+(i+1);
                    if (i==0) {
                        catfilterexp = catfilterexp +'contains (CategoryHashTag,'+ contentIdName+')';
                    } else {
                        catfilterexp = catfilterexp + " OR " +'contains (CategoryHashTag,'+ contentIdName+')';
                    }
                    expressionAttributeValues[contentIdName] ={ S: categoryarr[i]};
                }
                catfilterexp =catfilterexp +')';
                
            }

            if(catfilterexp!=''){
                if(filterExpression!=''){
                    filterExpression=filterExpression+' AND '+catfilterexp;
                }else {
                    filterExpression=filterExpression+catfilterexp;
                }
            }
            //console.log(req.params.categoryhashtag);
            //console.log(filterExpression);
            //console.log(expressionAttributeValues);
            var params = {
                TableName: process.env.SUBCATEGORY_TABLE,
                ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
                FilterExpression: filterExpression,
                ProjectionExpression: "SubCategoryHashTag_TC,CategoryHashTag_TC,SubCategoryName_TC,SubCategoryHashTag,CategoryHashTag,SubCategoryName",
            
            };
        } else {
            var params = {
                TableName: process.env.SUBCATEGORY_TABLE,
            };
        }

        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
            } else {
                //console.log(data);
                utility.successResponse(res, 'Success', data.Items);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'subcategory','subcategory_get_all',JSON.stringify(req.body));
    }
}


exports.subcategory_insert = (req, res) => {
    try {
  //Validation Check
        md = req.body;
        console.log(md);
        var SubCategoryHashTag_TC = md.SubCategoryHashTag_TC.trim();
        if (!SubCategoryHashTag_TC) 
        return utility.errorResponse(res, 'No SubCategoryHashTag_TC provided.',null);
        
        var SubCategoryName_TC = md.SubCategoryName_TC.trim();
        if (!SubCategoryName_TC) 
        return utility.errorResponse(res, 'No SubCategoryName_TC provided.',null);

        var CategoryHashTag_TC = md.CategoryHashTag_TC.trim();
        if (!CategoryHashTag_TC) 
        return utility.errorResponse(res, 'No CategoryHashTag_TC provided.',null);

        var SubCategoryHashTag = md.SubCategoryHashTag.trim();
        if (!SubCategoryHashTag) 
        return utility.errorResponse(res, 'No SubCategoryHashTag provided.',null);

        var SubCategoryName = md.SubCategoryName.trim();
        if (!SubCategoryName) 
        return utility.errorResponse(res, 'No SubCategoryName provided.',null);

        var CategoryHashTag = md.CategoryHashTag.trim();
        if (!CategoryHashTag) 
        return utility.errorResponse(res, 'No CategoryHashTag provided.',null);

    //Insert Data
        var params = {
            TableName: process.env.SUBCATEGORY_TABLE,
            Item:{
                SubCategoryHashTag_TC : { S:SubCategoryHashTag_TC},
                CategoryHashTag_TC : { S:CategoryHashTag_TC},
                SubCategoryName_TC : { S:SubCategoryName_TC},
                SubCategoryHashTag : { S:SubCategoryHashTag},
                CategoryHashTag : { S:CategoryHashTag},
                SubCategoryName : { S:SubCategoryName},
                IsActive:{ N : "1"}
            }
        };

        dynamodb.putItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
            } else {
                utility.successResponse(res, 'Success', data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'subcategory','subcategory_get_all',JSON.stringify(req.body));
    }
}

exports.subcategory_update = (req, res) => {
    try {
        md = req.body;
        //console.log(md);
        var SubCategoryHashTag_TC = md.SubCategoryHashTag_TC.trim();
        if (!SubCategoryHashTag_TC) 
        return utility.errorResponse(res, 'No SubCategoryHashTag_TC provided.',null);
        
        var SubCategoryName_TC = md.SubCategoryName_TC.trim();
        if (!SubCategoryName_TC) 
        return utility.errorResponse(res, 'No SubCategoryName_TC provided.',null);

        var CategoryHashTag_TC = md.CategoryHashTag_TC.trim();
        if (!CategoryHashTag_TC) 
        return utility.errorResponse(res, 'No CategoryHashTag_TC provided.',null);

        var SubCategoryHashTag = md.SubCategoryHashTag.trim();
        if (!SubCategoryHashTag) 
        return utility.errorResponse(res, 'No SubCategoryHashTag provided.',null);

        var SubCategoryName = md.SubCategoryName.trim();
        if (!SubCategoryName) 
        return utility.errorResponse(res, 'No SubCategoryName provided.',null);

        var CategoryHashTag = md.CategoryHashTag.trim();
        if (!CategoryHashTag) 
        return utility.errorResponse(res, 'No CategoryHashTag provided.',null);

    //Call update Method
        var params = {
            Key: {
                SubCategoryHashTag_TC : { S:md.Hashkey}
            },
            TableName: process.env.SUBCATEGORY_TABLE,
            UpdateExpression: "set CategoryHashTag_TC = :CategoryHashTag_TC, SubCategoryName_TC = :SubCategoryName_TC, SubCategoryHashTag = :SubCategoryHashTag, CategoryHashTag = :CategoryHashTag, SubCategoryName = :SubCategoryName, IsActive = :IsActive",
            ExpressionAttributeValues:{
                ":CategoryHashTag_TC" : { S:CategoryHashTag_TC},
                ":SubCategoryName_TC" : { S:SubCategoryName_TC},
                ":SubCategoryHashTag" : { S:SubCategoryHashTag},
                ":CategoryHashTag" : { S:CategoryHashTag},
                ":SubCategoryName" : { S:SubCategoryName},
                ":IsActive" : { N: "1"}
            },
            ReturnValues:"UPDATED_NEW"
        };
        dynamodb.updateItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
            } else {
                utility.successResponse(res, 'Success', data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'subcategory','subcategory_get_all',JSON.stringify(req.body));
    }
}
exports.subcategory_statuschange = (req, res) => {
    try {
    //Delete Call
        md=req.body;
        var params = {
            Key: {
                SubCategoryHashTag_TC: { S: md.SubCategoryHashTag }
            },
            TableName: process.env.SUBCATEGORY_TABLE,
            UpdateExpression: "set IsActive = :IsActive",
            ExpressionAttributeValues: {
                ":IsActive": { N : md.Status },
            },
            ReturnValues: "UPDATED_NEW"
        };
        dynamodb.updateItem(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    
    } catch (err) {
        utility.errorlog(err.stack,'subcategory','subcategory_get_all',JSON.stringify(req.body));
    }
}
exports.subcategory_delete = (req, res) => {
    try {
	//Delete Call
	// var params = {
	// 	Key: {
	// 		SubCategoryHashTag: { S: req.params.id }
	// 	},
	// 	TableName: process.env.SUBCATEGORY_TABLE,
	// 	UpdateExpression: "set IsActive = :IsActive",
	// 	ExpressionAttributeValues: {
	// 		":IsActive": { N : "0" },
	// 	},
	// 	ReturnValues: "UPDATED_NEW"
	// };
	// dynamodb.updateItem(params, function (err, data) {
	// 	if (err) {
	// 		utility.errorResponse(res, 'error', err);
	// 	} else {
	// 		utility.successResponse(res, 'Success', data)
	// 	}
    // });
    //console.log(req.params.id);
        var params = {
            Key: {
                SubCategoryHashTag_TC : { S:req.params.id}
            },
            TableName: process.env.SUBCATEGORY_TABLE
        };
        dynamodb.deleteItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
            } else {
                utility.successResponse(res, 'Success', data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'subcategory','subcategory_get_all',JSON.stringify(req.body));
    }
}


var express = require('express');
var router = express.Router();

var _ = require('lodash');
var path = require('path');
var multer = require('multer');
/* GET home page. */
// router.get('/', function(req, res, next) {
// 	res.render('index', { title: 'Upload Avatar', avatar_field: process.env.AVATAR_FIELD });
// });
exports.image_upload =  (req, res) => {
	var files;
	var file = req.file.filename;
	var matches = file.match(/^(.+?)_.+?\.(.+)$/i);
	console.log(matches);
	if (matches) {
		console.log(1111);
		files = _.map(['lg', 'md'], function(size) {
			return matches[1] + '_' + size + '.' + matches[2];
		});
	} else {
		console.log(2222);
		files = [file];
	}

	files = _.map(files, function(file) {
		console.log(file);
		var port = req.app.get('port');
		//var base = req.protocol + '://' + req.hostname + (port ? ':' + port : '');
		var url = path.join(req.file.baseUrl, file).replace(/[\\\/]+/g, '/').replace(/^[\/]+/g, '');
		if(file.indexOf('_md.png') > -1) {
			url = path.join(req.file.baseUrl_small, file).replace(/[\\\/]+/g, '/').replace(/^[\/]+/g, '');
		}
		else
		{
			url = path.join(req.file.baseUrl, file).replace(/[\\\/]+/g, '/').replace(/^[\/]+/g, '');
		}

		//return (req.file.storage == 'local' ? base : '') + '/' + url;
		return url;
	});

	res.json({
		images: files
	});
}
// router.post('/upload', upload.single(process.env.AVATAR_FIELD), function(req, res, next) {

// 	var files;
// 	var file = req.file.filename;
// 	var matches = file.match(/^(.+?)_.+?\.(.+)$/i);

// 	if (matches) {
// 		files = _.map(['lg', 'md', 'sm'], function(size) {
// 			return matches[1] + '_' + size + '.' + matches[2];
// 		});
// 	} else {
// 		files = [file];
// 	}

// 	files = _.map(files, function(file) {
// 		var port = req.app.get('port');
// 		var base = req.protocol + '://' + req.hostname + (port ? ':' + port : '');
// 		var url = path.join(req.file.baseUrl, file).replace(/[\\\/]+/g, '/').replace(/^[\/]+/g, '');

// 		return (req.file.storage == 'local' ? base : '') + '/' + url;
// 	});

// 	res.json({
// 		images: files
// 	});

// });

// module.exports = router;

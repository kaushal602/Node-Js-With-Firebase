var express = require('express');
var router = express.Router();

// s3.upload(params, function(err, data) {
//     console.log(err, data);
// });
exports.image_upload =  (req, res) => {
    
        res.send("Uploaded!");
	
}

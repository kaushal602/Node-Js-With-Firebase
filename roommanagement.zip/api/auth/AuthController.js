var express = require('express');
var utility = require('../Utility/Utility');
var modelUser = require('../../api/model/User');
require('dotenv').config();
var VerifyToken = require('./VerifyToken');
//var AWS = require("aws-sdk");

/**
 * Configure JWT
 */
var jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens
var bcrypt = require('bcryptjs');
var config = require('../../config'); // get config file

const fs = require('fs');
var wstream = fs.createWriteStream('errorLogFile.log');
var logtime = new Date();

    // exports.user_login = (req, res) => {
    //     try {
    //         md = req.body;
    //         var params = {
    //             TableName: process.env.USER_TABLE,
    //             Key: {
    //                 'Email' : {S: md.Email},
    //             },
    //         };
    //         dynamodb.getItem(params, function(err, data) {
    //             if (err) {
    //                 utility.errorResponse(res, 'server error',err);
    //                 utility.errorlog(err.stack,'Auth','user_login',JSON.stringify(req.body));
    //             } else {   
    //             //res.status(200).send(data);    
    //                 if (data.Item == null || data.Item == 'undefined'){
    //                     //wstream.write('['+logtime+']: No user found\r\n');
    //                     utility.errorlog('No user found','Auth','user_login',JSON.stringify(req.body));
    //                     utility.authFailResponse(res, 'No user found.',null,null);
    //                 } else {
    //                     var passwordIsValid = bcrypt.compareSync(req.body.Password, data.Item.Password['S']);
    //                     if (passwordIsValid == true) {
    //                         var token =jwt.sign({ Email: data.Item.Email }, config.secret, {
    //                             expiresIn: 86400 // expires in 24 hours
    //                         });
    //                         utility.authSuccessResponse(res, 'true',token,data);
    //                     } else {
    //                         utility.errorlog('Password not match.','Auth','user_login',JSON.stringify(req.body));
    //                         utility.authFailResponse(res,'false',null,null); 
    //                     }
    //                 }
    //             //res.status(200).send({ auth: true, token: token });
    //             }
    //         });
    //     } catch (err) {
    //         utility.errorlog(err.stack,'Auth','user_login',JSON.stringify(req.body));
    //         // ^ will output the "unexpected" result of: elsewhere has failed
    //     }
    // }


// router.get('/me', VerifyToken, function(req, res, next) {
//    //res.status(200).send(req.email);
//     var params = {
//       TableName: 'Users',
//       Key: {
//         'email' : {S: req.email['S']},
//       },
//     };
//     dynamodb.getItem(params, function(err, data) {
//       if (err) return res.status(500).send("There was a problem finding the user.");
//       if (!data) return res.status(404).send("No user found.");
//       res.status(200).send(data);
//     });
// });
// module.exports = router;
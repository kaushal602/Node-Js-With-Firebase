const express = require("express");
const router = express.Router();

var VerifyToken = require('../auth/VerifyToken');

const TransationController = require('../controller/transation/TransationController');


router.post("/addcontestparticipant", VerifyToken, TransationController.add_subscribe_user);
router.post("/updategroupdata", TransationController.update_grouptype_data);
router.post("/getcontestparticipant", TransationController.get_subscribe_user);
router.post("/getparticipantbytype", TransationController.get_participant_by_type);
router.post("/paymentsuccessemail", VerifyToken, TransationController.payment_email);
router.get("/gettransactionsdetails", TransationController.get_transation_details);
router.post("/contestlist", VerifyToken, TransationController.contestlist);
router.post("/submitedcontest", TransationController.submited_contestlist);
router.post("/contestwiseparticipatechild", VerifyToken,TransationController.contest_wise_participate_child);



module.exports = router;
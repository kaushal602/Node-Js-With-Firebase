const express = require("express");
const router = express.Router();

var VerifyToken = require('../auth/VerifyToken');
const CategoryController = require('../controller/master/CategoryController');

// var AWS = require("aws-sdk");
// multer = require('multer'),
// multerS3 = require('multer-s3');
// AWS.config.update({
//     region: process.env.region,
//     accessKeyId: process.env.aws_access_key_id,
//     secretAccessKey: process.env.aws_secret_access_key
//   });
// s3 = new AWS.S3();
// var upload = multer({
//     storage: multerS3({
//         s3: s3,
//         bucket: 'contest888-images',
//         key: function (req, file, cb) {
//             console.log(file);
//             console.log(req.body);
//             cb(null, file.originalname); //use Date.now() for unique file keys
//         }
//     })
// });
router.get("/", CategoryController.category_get_all);
router.get("/:id", CategoryController.category_get_by_id);
router.post("/", VerifyToken, CategoryController.category_insert);
router.post("/categorylist", CategoryController.category_get_all_adminside);
//router.post("/chinesecategory", CategoryController.chinese_category_insert);
router.put("/", VerifyToken, CategoryController.category_update);
router.delete("/:id", VerifyToken, CategoryController.category_delete);
router.post("/statuschange/", CategoryController.category_statuschange);
router.post("/image/", CategoryController.category_image);

module.exports = router;
const express = require("express");
const router = express.Router();

var VerifyToken = require('../auth/AuthController');
const AuthController = require('../auth/AuthController');

router.post("/", AuthController.user_login);

module.exports = router;
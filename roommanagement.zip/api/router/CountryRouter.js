const express = require("express");
const router = express.Router();

const CountryController = require('../controller/master/CountryController');

router.get("/", CountryController.country_get_all);
router.post("/countrylist", CountryController.country_get_adminside);
router.get("/:id", CountryController.country_get_by_id);
router.post("/", CountryController.country_insert);
router.put("/", CountryController.country_update);
router.put("/statuschange/", CountryController.country_statuschange);
router.delete("/:id", CountryController.country_delete);

module.exports = router;
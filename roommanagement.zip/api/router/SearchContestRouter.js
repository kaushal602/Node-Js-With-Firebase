const express = require("express");
const router = express.Router();

const CotestController = require('../controller/contest/ContestController');

router.get("/:country?/:category?/:subcategory?/:contest?/:price?/:contestname?/:prefLang?", CotestController.search_contest);


module.exports = router;